# FuelSight v2.2 – new APIs
Swagger UI (try every endpoint): http://127.0.0.1:8001/docs  (tags: inventory & status, regional demand, transport & routes, supply & delays, crisis conditions)

Design rule: the official simulator is never modified. Operator data (vehicles, route constraints, delays, crises, status overrides,
regional multipliers) is stored in FuelSight's SQLite DB and is applied on top of simulator data ("effective view").
The effective view feeds risk, forecasts, recommendations AND the approve pre-check.

## Inventory & station status
| Method | Path | Notes |
|---|---|---|
| GET | /api/inventory/summary | fill % per fuel (stations+depots), status + risk counts |
| GET | /api/inventory/stations?region_id=&fuel=&status= | per fuel: inventory, capacity, fill %, forecast L/h, hours to stockout, risk |
| GET | /api/inventory/depots?region_id= | + dispatch capacity, vehicles available |
| GET | /api/stations , /api/depots | raw effective objects (status, status_source: simulator/operator/crisis) |
| POST | /api/stations/{id}/status | `{"status":"OPEN|CLOSED","reason":"..."}` |
| POST | /api/depots/{id}/status | `{"status":"OPEN|CONSTRAINED|CLOSED"}` |
| DELETE | /api/stations/{id}/status , /api/depots/{id}/status | remove override |

## Regional demand
| Method | Path | Notes |
|---|---|---|
| GET | /api/regions/demand | all regions: forecast L/h, observed L/h, inventory, cover hours, risk counts |
| GET | /api/regions/{region_id}/demand | + per-station rows + 24h hourly forecast |
| POST | /api/regions/{region_id}/demand-override | `{"multiplier":1.5,"note":"Eid"}` (0.1 < x <= 5) |
| DELETE | /api/regions/{region_id}/demand-override | |

## Transport, routes, travel constraints
| GET | /api/transport/vehicles?depot_id=&status= | 2 tankers per depot are seeded once |
| POST | /api/transport/vehicles | `{"name":"T3","capacity_liters":8000,"depot_id":"depot-gazipur","fuel_types":["DIESEL"]}` |
| GET / PUT / DELETE | /api/transport/vehicles/{id} | |
| POST | /api/transport/vehicles/{id}/status | AVAILABLE / IN_TRANSIT / MAINTENANCE / OFFLINE |
| GET | /api/transport/routes?blocked=&depot_id=&station_id= | travel minutes, effective max load, block reasons, vehicles available |
| GET | /api/transport/routes/{id} | |
| PUT | /api/transport/routes/{id}/constraints | `{"blocked":false,"max_load_liters":3000,"extra_delay_ticks":2,"reason":"flood"}` |
| DELETE | /api/transport/routes/{id}/constraints | |
| POST | /api/transport/plan | dry-run: `{"route_id":"route-gazipur-mirpur","fuel_type":"DIESEL","quantity":3000}` -> feasible, errors, ETA, trips, station after delivery |

Constraint effects: `blocked` -> route DISRUPTED; `max_load_liters` lowers max shipment; `extra_delay_ticks` adds to transit time.
Fleet rule: if a depot has registered vehicles but none is AVAILABLE for that fuel -> `NO_VEHICLE_AVAILABLE` (plan + approve).

## Supply delays
| GET | /api/supply/arrivals?delayed=&depot_id= | arrivals with `effective_tick = planned_tick + delays` + summary |
| GET | /api/supply/delays?status=ACTIVE | |
| POST | /api/supply/delays | `{"arrival_id":7,"delay_ticks":5}` or `{"depot_id":"depot-gazipur","fuel_type":"DIESEL","delay_ticks":6,"reason":"port strike"}` |
| POST | /api/supply/delays/{id}/resolve | |
| DELETE | /api/supply/delays/{id} | |

## Crisis conditions
| GET | /api/crises?status=ACTIVE|SCHEDULED|EXPIRED|RESOLVED | state is computed from simulator tick |
| GET | /api/crises/level | NORMAL / WATCH / ELEVATED / SEVERE / CRITICAL (active crises + live stockout risk) |
| POST | /api/crises | see below |
| GET | /api/crises/{id} | |
| POST | /api/crises/{id}/resolve | |
| DELETE | /api/crises/{id} | |

Types and their effect: DEMAND_SPIKE (region/stations x multiplier), ROUTE_DISRUPTION (routes blocked), DEPOT_OUTAGE (depots CLOSED),
STATION_CLOSURE (stations CLOSED), SUPPLY_DELAY (arrivals shifted), FUEL_SHORTAGE / OTHER (advisory, raises crisis level).
`forward_to_simulator:true` (DEMAND_SPIKE, ROUTE_DISRUPTION only) also calls `POST /admin/events` on the simulator; when it succeeds the
effect comes from the simulator itself (not applied twice). If the forward fails the crisis is still applied locally and `forward_error` explains why.

## PowerShell examples
```powershell
Invoke-RestMethod http://127.0.0.1:8001/api/inventory/summary
Invoke-RestMethod http://127.0.0.1:8001/api/crises/level
$b = @{type="DEMAND_SPIKE";severity="HIGH";title="Eid rush";region_id="region-dhaka";demand_multiplier=2;duration_ticks=48} | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8001/api/crises -ContentType "application/json" -Body $b
$c = @{blocked=$false;max_load_liters=2000;extra_delay_ticks=3;reason="flood"} | ConvertTo-Json
Invoke-RestMethod -Method Put -Uri http://127.0.0.1:8001/api/transport/routes/route-gazipur-mirpur/constraints -ContentType "application/json" -Body $c
$p = @{route_id="route-gazipur-mirpur";fuel_type="DIESEL";quantity=1500} | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8001/api/transport/plan -ContentType "application/json" -Body $p
Invoke-RestMethod -Method Delete http://127.0.0.1:8001/api/crises/1
```
