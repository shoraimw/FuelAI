# FuelSight Analysis & Forecasting

## Manual mode
Operators can select Dhaka/Chattogram, depot/station, fuel type, horizon, storage, capacity, incoming supply, growth and demand multiplier. Hourly demand observations can be entered manually.

## Model
The dependency-free `FuelSight Ensemble Demand Model` combines exponential smoothing, recent-window average and a linear trend. It returns an explicit confidence estimate and model metadata so the forecast is explainable.

## Storage prediction
The model projects inventory hour-by-hour, accounts for incoming supply, calculates safety-stock crossing and projected stockout.

## Decision
The system computes a recommended refill quantity and explains the drivers. Manual analysis does not directly mutate the BUP simulator. Simulator-backed recommendations continue to use the human approval workflow and `POST /v1/allocations`.
