# FuelSight Architecture

The official simulator remains the operational world. FuelSight owns data collection, prediction, risk scoring, recommendation generation, operator review, observability and recovery behavior.

```text
Simulator
   |
REST + SSE
   |
Simulator Client
 retry / timeout / circuit breaker / stale detection
   |
Collector
   |
SQLite snapshots + demand history
   |
+-------------------+
| Intelligence      |
| forecast          |
| stockout risk     |
| anomaly detection |
+---------+---------+
          |
Decision Engine
 route + inventory + capacity constraints
 greedy recommendation
 what-if impact
          |
Human Approval
          |
POST /v1/allocations
```
