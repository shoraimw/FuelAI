# Connection fixes (v2 -> v2.1)
1. CORS: backend allowed only `localhost:5173`, UI runs on `127.0.0.1:5173` -> browser blocked every call. Fixed (regex for localhost/127.0.0.1) AND frontend now uses Vite proxy (`/api` -> 8001), so no CORS at all.
2. Syntax errors: `exportdefault` (5 pages) and `importRiskBadgefrom` (Alerts, Recommendations) -> pages/app crashed. Fixed.
3. SSE: server sends named event `update`, UI listened to `onmessage` (never fired). Fixed.
4. Simulator (port 8000) not running + MOCK_MODE=false = empty UI. Added AUTO_MOCK_FALLBACK; mock now auto-ticks, has seeded history, delivers allocations.
5. `.env`/DB path depended on the folder you launch from. Now always repo root.
6. Approve failed (`idempotency_key` missing in allocation). Fixed.
7. Anomaly detector compared per-tick vs per-hour values -> false alerts. Forecast hour-of-day now follows sim clock.
8. `pytest.ini` had literal `\n`; package.json used `latest` -> pinned versions.
9. UI now shows a real error/banner instead of infinite "Loading".

# v2.2 – new features
Inventory & Status, Regional Demand, Transport & Routes (+ travel constraints, fleet, shipment planner), Supply & Delays, Crisis Conditions.
Backend: backend/app/api/{inventory,regions,transport,supply,crisis}.py, backend/app/ops/. Frontend: 5 new sidebar pages. Tests: backend/tests/test_ops_api.py (13). Reference: docs/API.md
