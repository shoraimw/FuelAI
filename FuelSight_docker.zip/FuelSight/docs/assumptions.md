# Assumptions

- The official simulator is external to FuelSight and remains the source of truth.
- REST is authoritative; SSE is advisory.
- Demand history requests are bounded.
- The baseline intelligence model is transparent and can be replaced later.
- Allocation approval remains human-controlled.
- SQLite keeps native Windows setup simple.
- Docker is not required for FuelSight.
- No real fuel infrastructure is accessed.
