# Demo Script

**0:00–1:00** Dashboard: explain the network, service level and risk.

**1:00–2:00** Step the simulator. Show that the state changes.

**2:00–3:00** Inject Dhaka demand spike ×1.8. Show anomaly/risk.

**3:00–4:00** Generate recommendation. Explain source depot, destination, route, quantity, transit and projected risk reduction.

**4:00–5:00** Approve & Send. Emphasize human-in-the-loop.

**5:00–6:00** Inject route disruption and show that unavailable routes are rejected by the pre-check.

**6:00–7:00** Inject simulator latency/error/unavailable. Show degraded mode, retry and circuit breaker.

**7:00–8:00** Clear fault, show recovery, then show metrics/load-test evidence.
