
import { Routes, Route, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { api } from './lib/api';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import Dashboard from './pages/Dashboard';
import Alerts from './pages/Alerts';
import Recommendations from './pages/Recommendations';
import Decisions from './pages/Decisions';
import Scenarios from './pages/Scenarios';
import System from './pages/System';
import Analysis from './pages/Analysis';
import Inventory from './pages/Inventory';
import Regions from './pages/Regions';
import Transport from './pages/Transport';
import Supply from './pages/Supply';
import Crisis from './pages/Crisis';

export default function App() {
  const [o,setO]=useState<any>({instance:{},stale:false});
  useEffect(()=>{const l=()=>api('/api/state/overview').then(setO).catch(()=>{});l();const t=setInterval(l,5000);return()=>clearInterval(t)},[]);
  return <div className="app-shell"><Sidebar/><main className="main"><Topbar instance={o.instance} stale={o.stale} mode={o.mode}/><div className="content"><Routes>
    <Route path="/" element={<Dashboard/>}/>
    <Route path="/analysis" element={<Analysis/>}/>
    <Route path="/inventory" element={<Inventory/>}/>
    <Route path="/regions" element={<Regions/>}/>
    <Route path="/transport" element={<Transport/>}/>
    <Route path="/supply" element={<Supply/>}/>
    <Route path="/crisis" element={<Crisis/>}/>
    <Route path="/alerts" element={<Alerts/>}/>
    <Route path="/recommendations" element={<Recommendations/>}/>
    <Route path="/decisions" element={<Decisions/>}/>
    <Route path="/scenarios" element={<Scenarios/>}/>
    <Route path="/system" element={<System/>}/>
  </Routes></div></main></div>;
}
