import { useState } from 'react';
import { post, del } from '../lib/api';
import { useApi, useAction } from '../lib/hooks';
import MetricCard from '../components/MetricCard';
import Notice from '../components/Notice';

export default function Supply() {
  const arr = useApi('/api/supply/arrivals'), dl = useApi('/api/supply/delays'), ov = useApi('/api/state/overview', 15000);
  const reload = () => { arr.reload(); dl.reload(); };
  const { msg, run } = useAction(reload);
  const [f, setF] = useState<any>({ arrival_id: '', depot_id: '', fuel_type: '', delay_ticks: 4, reason: '' });
  const depots: any[] = ov.data?.depots || [];
  const S = arr.data?.summary;
  const submit = () => run(() => post('/api/supply/delays', { arrival_id: f.arrival_id || null, depot_id: f.depot_id || null, fuel_type: f.fuel_type || null, delay_ticks: Number(f.delay_ticks), reason: f.reason || null }), 'Supply delay recorded');
  return <>
    <Notice msg={msg} error={arr.error || dl.error} />
    {S && <div className="grid metrics"><MetricCard label="INCOMING SHIPMENTS" value={S.total} sub={`tick ${arr.data.tick}`} /><MetricCard label="DELAYED" value={S.delayed} tone={S.delayed ? 'warn' : ''} sub={`${Math.round(S.delayed_liters).toLocaleString()} L affected`} /><MetricCard label="MAX DELAY" value={S.max_delay_ticks + ' ticks'} /><MetricCard label="ACTIVE DELAY RULES" value={(dl.data || []).filter((x: any) => x.status === 'ACTIVE').length} /></div>}
    <div className="panel"><div className="panel-head"><div><span className="eyebrow">INCOMING SUPPLY</span><h2>Supply arrivals</h2></div><span className="muted">GET /api/supply/arrivals</span></div>
      {(arr.data?.arrivals || []).length === 0 ? <div className="empty">No supply arrivals reported by the simulator.</div> :
        <div className="table-wrap"><table><thead><tr><th>Depot</th><th>Fuel</th><th>Quantity</th><th>Planned tick</th><th>Effective tick</th><th>Status</th><th></th></tr></thead><tbody>
          {arr.data.arrivals.map((a: any) => <tr key={a.id}><td>{a.depot_id}</td><td>{a.fuel_type}</td><td>{Number(a.quantity).toLocaleString()} L</td><td>{a.planned_tick}</td>
            <td>{a.delayed ? <b style={{ color: '#f4c96e' }}>{a.effective_tick} (+{a.delay_ticks})</b> : a.effective_tick}</td><td><span className="status">{a.status}</span></td>
            <td><button onClick={() => setF({ ...f, arrival_id: String(a.id), depot_id: '', fuel_type: '' })}>Delay</button></td></tr>)}
        </tbody></table></div>}
    </div>
    <div className="panel"><div className="panel-head"><div><span className="eyebrow">REPORT DELAY</span><h2>Add supply delay</h2></div><span className="muted">POST /api/supply/delays</span></div>
      <div className="analysis-form">
        <label>Arrival ID (optional)<input value={f.arrival_id} onChange={e => setF({ ...f, arrival_id: e.target.value })} placeholder="or pick depot below" /></label>
        <label>Depot<select value={f.depot_id} onChange={e => setF({ ...f, depot_id: e.target.value })}><option value="">—</option>{depots.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select></label>
        <label>Fuel<select value={f.fuel_type} onChange={e => setF({ ...f, fuel_type: e.target.value })}><option value="">All fuels</option><option>DIESEL</option><option>PETROL</option><option>OCTANE</option></select></label>
        <label>Delay (ticks)<input type="number" min={1} value={f.delay_ticks} onChange={e => setF({ ...f, delay_ticks: e.target.value })} /></label>
        <label>Reason<input value={f.reason} onChange={e => setF({ ...f, reason: e.target.value })} placeholder="port congestion…" /></label></div>
      <div className="actions"><button className="primary" disabled={!f.arrival_id && !f.depot_id} onClick={submit}>Record delay</button></div>
    </div>
    <div className="panel"><div className="panel-head"><h2>Delay log</h2></div>
      {(dl.data || []).length === 0 ? <div className="empty">No delays recorded.</div> : (dl.data || []).map((x: any) => <div className="list-row" key={x.id}>
        <div><b>{x.arrival_id ? `Arrival #${x.arrival_id}` : x.depot_id} {x.fuel_type || ''}</b><small>+{x.delay_ticks} ticks · {x.reason || 'no reason'}</small></div><span className="status">{x.status}</span>
        <div className="actions">{x.status === 'ACTIVE' && <button onClick={() => run(() => post(`/api/supply/delays/${x.id}/resolve`), 'Delay resolved')}>Resolve</button>}<button onClick={() => run(() => del(`/api/supply/delays/${x.id}`), 'Deleted')}>Delete</button></div></div>)}
    </div>
  </>;
}
