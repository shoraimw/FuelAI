import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { post, del } from '../lib/api';
import { useApi, useAction } from '../lib/hooks';
import Notice from '../components/Notice';

const FUELS = ['DIESEL', 'PETROL', 'OCTANE'];

export default function Regions() {
  const all = useApi('/api/regions/demand');
  const [sel, setSel] = useState('');
  const [mult, setMult] = useState('1.5');
  const [note, setNote] = useState('');
  const regions: any[] = all.data?.regions || [];
  const cur = sel || regions[0]?.region_id || '';
  const detail = useApi(cur ? `/api/regions/${cur}/demand` : '/api/regions/demand');
  const reload = () => { all.reload(); detail.reload(); };
  const { msg, run } = useAction(reload);
  const d = cur && detail.data?.region_id === cur ? detail.data : undefined;
  return <>
    <Notice msg={msg} error={all.error} />
    <div className="two">{regions.map(r => <div key={r.region_id} className={'panel clickable ' + (r.region_id === cur ? 'selected' : '')} onClick={() => setSel(r.region_id)}>
      <div className="panel-head"><div><span className="eyebrow">REGIONAL DEMAND</span><h2>{r.name}</h2></div>
        <span className="status">factor {r.demand_factor}{r.operator_override ? ` · override ×${r.operator_override.multiplier}` : ''}{r.crisis_multiplier !== 1 ? ` · crisis ×${r.crisis_multiplier}` : ''}</span></div>
      <div className="table-wrap"><table><thead><tr><th>Fuel</th><th>Forecast L/h</th><th>Observed L/h</th><th>Inventory</th><th>Cover</th></tr></thead><tbody>
        {FUELS.map(f => <tr key={f}><td>{f}</td><td>{r.fuels[f].forecast_liters_per_hour.toLocaleString()}</td><td>{r.fuels[f].observed_liters_per_hour.toLocaleString()}</td><td>{Math.round(r.fuels[f].inventory_liters).toLocaleString()} L</td><td>{r.fuels[f].cover_hours} h</td></tr>)}
      </tbody></table></div>
      <p className="muted">{r.stations} stations · 24h forecast {Math.round(r.total_forecast_24h_liters).toLocaleString()} L · risks: {r.risk_counts.CRITICAL} critical, {r.risk_counts.HIGH} high, {r.risk_counts.MEDIUM} medium</p>
    </div>)}</div>
    {cur && <div className="panel"><div className="panel-head"><div><span className="eyebrow">PLANNING OVERRIDE</span><h2>Adjust regional demand — {d?.name || cur}</h2></div><span className="muted">POST /api/regions/{'{id}'}/demand-override</span></div>
      <div className="analysis-form">
        <label>Multiplier (1.0 = normal)<input type="number" step="0.05" value={mult} onChange={e => setMult(e.target.value)} /></label>
        <label>Note<input value={note} onChange={e => setNote(e.target.value)} placeholder="Eid rush, harvest…" /></label>
      </div>
      <div className="actions"><button className="primary" onClick={() => run(() => post(`/api/regions/${cur}/demand-override`, { multiplier: Number(mult), note }), 'Regional demand updated')}>Apply</button>
        <button onClick={() => run(() => del(`/api/regions/${cur}/demand-override`), 'Override removed')}>Clear override</button></div>
      {d && <ResponsiveContainer width="100%" height={280}><LineChart data={d.hourly_forecast}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="hour" /><YAxis /><Tooltip /><Legend />
        <Line dataKey="DIESEL" dot={false} /><Line dataKey="PETROL" dot={false} stroke="#f4c96e" /><Line dataKey="OCTANE" dot={false} stroke="#75d9a3" /><Line dataKey="total" dot={false} strokeDasharray="5 5" stroke="#ff858b" /></LineChart></ResponsiveContainer>}
    </div>}
  </>;
}
