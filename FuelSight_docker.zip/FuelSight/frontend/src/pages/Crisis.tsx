import { useState } from 'react';
import { post, del } from '../lib/api';
import { useApi, useAction } from '../lib/hooks';
import MetricCard from '../components/MetricCard';
import RiskBadge from '../components/RiskBadge';
import Notice from '../components/Notice';

const TYPES = ['DEMAND_SPIKE', 'ROUTE_DISRUPTION', 'DEPOT_OUTAGE', 'STATION_CLOSURE', 'SUPPLY_DELAY', 'FUEL_SHORTAGE', 'OTHER'];
const tone = (l: string) => l === 'CRITICAL' || l === 'SEVERE' ? 'danger' : l === 'ELEVATED' ? 'warn' : '';

export default function Crisis() {
  const lv = useApi('/api/crises/level', 5000), list = useApi('/api/crises'), ov = useApi('/api/state/overview', 15000);
  const reload = () => { lv.reload(); list.reload(); };
  const { msg, run } = useAction(reload);
  const [f, setF] = useState<any>({ type: 'DEMAND_SPIKE', severity: 'HIGH', title: '', region_id: '', station_id: '', route_id: '', depot_id: '', fuel_type: '', demand_multiplier: 1.5, delay_ticks: 4, duration_ticks: 48, note: '', forward: false });
  const regions: any[] = ov.data?.regions || [], stations: any[] = ov.data?.stations || [], routes: any[] = ov.data?.routes || [], depots: any[] = ov.data?.depots || [];
  const set = (k: string, v: any) => setF((x: any) => ({ ...x, [k]: v }));
  const t = f.type;
  const submit = () => run(async () => {
    const r: any = await post('/api/crises', { type: t, severity: f.severity, title: f.title, region_id: f.region_id || null, station_ids: f.station_id ? [f.station_id] : [], route_ids: f.route_id ? [f.route_id] : [], depot_ids: f.depot_id ? [f.depot_id] : [],
      fuel_type: f.fuel_type || null, demand_multiplier: Number(f.demand_multiplier), delay_ticks: t === 'SUPPLY_DELAY' ? Number(f.delay_ticks) : 0, duration_ticks: f.duration_ticks ? Number(f.duration_ticks) : null, note: f.note || null, forward_to_simulator: f.forward });
    if (r.forward_error) throw new Error('Crisis saved locally, but simulator forward failed: ' + r.forward_error);
  }, 'Crisis condition activated');
  const L = lv.data;
  return <>
    <Notice msg={msg} error={lv.error || list.error} />
    {L && <div className="grid metrics"><MetricCard label="NETWORK CRISIS LEVEL" value={L.level} tone={tone(L.level)} sub={`tick ${L.tick}`} /><MetricCard label="ACTIVE CRISES" value={L.active_crises} /><MetricCard label="CRITICAL RISKS" value={L.critical_risks} tone={L.critical_risks ? 'danger' : ''} /><MetricCard label="HIGH RISKS" value={L.high_risks} tone={L.high_risks ? 'warn' : ''} /></div>}
    <div className="two">
      <div className="panel"><div className="panel-head"><div><span className="eyebrow">DECLARE</span><h2>New crisis condition</h2></div><span className="muted">POST /api/crises</span></div>
        <div className="analysis-form" style={{ gridTemplateColumns: 'repeat(2,1fr)' }}>
          <label>Type<select value={t} onChange={e => set('type', e.target.value)}>{TYPES.map(x => <option key={x}>{x}</option>)}</select></label>
          <label>Severity<select value={f.severity} onChange={e => set('severity', e.target.value)}><option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>CRITICAL</option></select></label>
          <label>Title<input value={f.title} onChange={e => set('title', e.target.value)} placeholder="Flood on Dhaka–Gazipur road" /></label>
          <label>Duration (ticks)<input type="number" value={f.duration_ticks} onChange={e => set('duration_ticks', e.target.value)} placeholder="until resolved" /></label>
          {t === 'DEMAND_SPIKE' && <><label>Region<select value={f.region_id} onChange={e => set('region_id', e.target.value)}><option value="">—</option>{regions.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}</select></label>
            <label>Demand multiplier<input type="number" step="0.1" value={f.demand_multiplier} onChange={e => set('demand_multiplier', e.target.value)} /></label></>}
          {(t === 'STATION_CLOSURE' || t === 'DEMAND_SPIKE') && <label>Station{t === 'DEMAND_SPIKE' ? ' (optional)' : ''}<select value={f.station_id} onChange={e => set('station_id', e.target.value)}><option value="">—</option>{stations.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select></label>}
          {t === 'ROUTE_DISRUPTION' && <label>Route<select value={f.route_id} onChange={e => set('route_id', e.target.value)}><option value="">—</option>{routes.map(r => <option key={r.id} value={r.id}>{r.id}</option>)}</select></label>}
          {(t === 'DEPOT_OUTAGE' || t === 'SUPPLY_DELAY') && <label>Depot{t === 'SUPPLY_DELAY' ? ' (blank = all)' : ''}<select value={f.depot_id} onChange={e => set('depot_id', e.target.value)}><option value="">—</option>{depots.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select></label>}
          {t === 'SUPPLY_DELAY' && <label>Delay (ticks)<input type="number" value={f.delay_ticks} onChange={e => set('delay_ticks', e.target.value)} /></label>}
          {(t === 'SUPPLY_DELAY' || t === 'FUEL_SHORTAGE') && <label>Fuel<select value={f.fuel_type} onChange={e => set('fuel_type', e.target.value)}><option value="">All</option><option>DIESEL</option><option>PETROL</option><option>OCTANE</option></select></label>}
          <label style={{ gridColumn: '1/-1' }}>Note<input value={f.note} onChange={e => set('note', e.target.value)} /></label>
        </div>
        {(t === 'DEMAND_SPIKE' || t === 'ROUTE_DISRUPTION') && <label className="check"><input type="checkbox" checked={f.forward} onChange={e => set('forward', e.target.checked)} /> Also inject into the simulator (POST /admin/events)</label>}
        <div className="actions"><button className="primary" disabled={!f.title} onClick={submit}>Activate crisis</button></div>
      </div>
      <div className="panel"><div className="panel-head"><div><span className="eyebrow">LIVE</span><h2>Crisis register</h2></div><span className="muted">GET /api/crises</span></div>
        {(list.data || []).length === 0 ? <div className="empty">No crisis conditions declared.</div> : (list.data || []).map((c: any) => <div className="alert-card" key={c.id}><RiskBadge risk={c.severity} />
          <div><b>{c.title}</b><p>{c.type} · <span className="status">{c.state}</span>{c.forwarded && <span className="status">SIMULATOR</span>}</p>
            <small>start tick {c.start_tick}{c.ends_at_tick !== null ? ` → ${c.ends_at_tick}` : ' · open-ended'}{c.region_id ? ` · ${c.region_id}` : ''}{c.demand_multiplier !== 1 && c.type === 'DEMAND_SPIKE' ? ` · ×${c.demand_multiplier}` : ''}</small></div>
          <div className="actions">{c.state === 'ACTIVE' || c.state === 'SCHEDULED' ? <button onClick={() => run(() => post(`/api/crises/${c.id}/resolve`), 'Crisis resolved')}>Resolve</button> : null}<button onClick={() => run(() => del(`/api/crises/${c.id}`), 'Deleted')}>Delete</button></div></div>)}
      </div>
    </div>
  </>;
}
