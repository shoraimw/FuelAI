import { post, del } from '../lib/api';
import { useApi, useAction } from '../lib/hooks';
import MetricCard from '../components/MetricCard';
import RiskBadge from '../components/RiskBadge';
import Notice from '../components/Notice';

const FUELS = ['DIESEL', 'PETROL', 'OCTANE'];
const cell = (f: any) => f ? <div><b>{Math.round(f.inventory_liters).toLocaleString()}</b> / {Math.round(f.capacity_liters).toLocaleString()} L<div className="bar"><i style={{ width: Math.min(100, f.fill_percent) + '%' }} /></div><small>{f.fill_percent}%{f.hours_to_stockout !== undefined && f.hours_to_stockout !== null ? ` · ${f.hours_to_stockout}h cover` : ''}</small></div> : '—';

export default function Inventory() {
  const sum = useApi('/api/inventory/summary'), st = useApi('/api/inventory/stations'), dp = useApi('/api/inventory/depots');
  const reload = () => { sum.reload(); st.reload(); dp.reload(); };
  const { msg, run } = useAction(reload);
  const err = sum.error || st.error || dp.error;
  const setStatus = (kind: string, id: string, status: string) => run(() => post(`/api/${kind}/${id}/status`, { status, reason: 'Set from UI' }), `${id} → ${status}`);
  const clear = (kind: string, id: string) => run(() => del(`/api/${kind}/${id}/status`), 'Override cleared');
  const S = sum.data;
  return <>
    <Notice msg={msg} error={err} />
    {S && <div className="grid metrics">{FUELS.map(f => <MetricCard key={f} label={f + ' · STATIONS'} value={S.fuels[f].stations_fill_percent + '%'} sub={`${Math.round(S.fuels[f].stations_inventory_liters).toLocaleString()} L · depots ${S.fuels[f].depots_fill_percent}%`} />)}
      <MetricCard label="STATION STATUS" value={Object.entries(S.station_status).map(([k, v]) => `${v} ${k}`).join(' · ')} sub={`Tick ${S.tick} · ${S.mode}`} tone={S.station_status.CLOSED ? 'warn' : ''} /></div>}
    <div className="panel"><div className="panel-head"><div><span className="eyebrow">CURRENT INVENTORY</span><h2>Stations</h2></div><span className="muted">GET /api/inventory/stations</span></div>
      <div className="table-wrap"><table><thead><tr><th>Station</th><th>Status</th>{FUELS.map(f => <th key={f}>{f}</th>)}<th>Risk</th></tr></thead><tbody>
        {(st.data || []).map((x: any) => <tr key={x.id}><td><b>{x.name}</b><br /><small>{x.region_name} · ×{x.demand_multiplier}</small></td>
          <td><select value={x.status} onChange={e => setStatus('stations', x.id, e.target.value)}><option>OPEN</option><option>CLOSED</option></select>
            <br /><small>{x.status_source}</small>{x.status_source === 'operator' && <button className="link" onClick={() => clear('stations', x.id)}>reset</button>}</td>
          {FUELS.map(f => <td key={f}>{cell(x.fuels.find((y: any) => y.fuel_type === f))}</td>)}<td><RiskBadge risk={x.worst_risk} /></td></tr>)}
      </tbody></table></div></div>
    <div className="panel"><div className="panel-head"><div><span className="eyebrow">SOURCE STOCK</span><h2>Depots</h2></div><span className="muted">GET /api/inventory/depots</span></div>
      <div className="table-wrap"><table><thead><tr><th>Depot</th><th>Status</th>{FUELS.map(f => <th key={f}>{f}</th>)}<th>Dispatch/tick</th><th>Vehicles</th></tr></thead><tbody>
        {(dp.data || []).map((x: any) => <tr key={x.id}><td><b>{x.name}</b><br /><small>{x.region_name}</small></td>
          <td><select value={x.status} onChange={e => setStatus('depots', x.id, e.target.value)}><option>OPEN</option><option>CONSTRAINED</option><option>CLOSED</option></select>
            <br /><small>{x.status_source}</small>{x.status_source === 'operator' && <button className="link" onClick={() => clear('depots', x.id)}>reset</button>}</td>
          {FUELS.map(f => <td key={f}>{cell(x.fuels.find((y: any) => y.fuel_type === f))}</td>)}<td>{x.dispatch_capacity_per_tick?.toLocaleString()} L</td><td>{x.vehicles_available}/{x.vehicles_total}</td></tr>)}
      </tbody></table></div></div>
  </>;
}
