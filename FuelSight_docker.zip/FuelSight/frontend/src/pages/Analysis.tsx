
import{useState}from'react';import{post,api}from'../lib/api';import{LineChart,Line,XAxis,YAxis,CartesianGrid,Tooltip,Legend,ResponsiveContainer}from'recharts';
const seed=[0,0,0,0,0,0];
export default function Analysis(){
 const [f,setF]=useState<any>({region:'Dhaka',active:true,location_type:'station',location:'Mirpur',fuel_type:'DIESEL',horizon_hours:24,current_storage_liters:3600,storage_capacity_liters:15000,incoming_supply_liters:0,incoming_supply_after_hours:0,growth_percent:0,demand_multiplier:1,safety_stock_percent:25,demand_points:seed.map((_,i)=>({hour:i+1,demand_liters:800+i*40}))});
 const [r,setR]=useState<any>(); const [busy,setBusy]=useState(false);
 const set=(k:string,v:any)=>setF((x:any)=>({...x,[k]:v}));
 const setPoint=(i:number,v:string)=>setF((x:any)=>({...x,demand_points:x.demand_points.map((p:any,j:number)=>j===i?{...p,demand_liters:Number(v)}:p)}));
 const run=async()=>{setBusy(true);try{setR(await post('/api/analysis/manual',f))}catch(e:any){alert(e.message)}finally{setBusy(false)}};
 return <div>
  <div className="panel">
   <div className="panel-head"><div><span className="eyebrow">MANUAL ANALYSIS</span><h2>Demand & Storage Planning</h2></div><span className="muted">Operator-controlled input</span></div>
   <div className="analysis-form">
    <label>Region<select value={f.region} onChange={e=>set('region',e.target.value)}><option>Dhaka</option><option>Chattogram</option></select></label>
    <label>Active<select value={String(f.active)} onChange={e=>set('active',e.target.value==='true')}><option value="true">Yes</option><option value="false">No</option></select></label>
    <label>Location Type<select value={f.location_type} onChange={e=>set('location_type',e.target.value)}><option value="station">Station</option><option value="depot">Depot</option></select></label>
    <label>Location<input value={f.location} onChange={e=>set('location',e.target.value)}/></label>
    <label>Fuel<select value={f.fuel_type} onChange={e=>set('fuel_type',e.target.value)}><option>DIESEL</option><option>PETROL</option><option>OCTANE</option></select></label>
    <label>Forecast Hours<input type="number" value={f.horizon_hours} onChange={e=>set('horizon_hours',Number(e.target.value))}/></label>
    <label>Current Storage (L)<input type="number" value={f.current_storage_liters} onChange={e=>set('current_storage_liters',Number(e.target.value))}/></label>
    <label>Capacity (L)<input type="number" value={f.storage_capacity_liters} onChange={e=>set('storage_capacity_liters',Number(e.target.value))}/></label>
    <label>Incoming Supply (L)<input type="number" value={f.incoming_supply_liters} onChange={e=>set('incoming_supply_liters',Number(e.target.value))}/></label>
    <label>Arrival After (h)<input type="number" value={f.incoming_supply_after_hours} onChange={e=>set('incoming_supply_after_hours',Number(e.target.value))}/></label>
    <label>Growth (%)<input type="number" value={f.growth_percent} onChange={e=>set('growth_percent',Number(e.target.value))}/></label>
    <label>Demand Multiplier<input type="number" step=".05" value={f.demand_multiplier} onChange={e=>set('demand_multiplier',Number(e.target.value))}/></label>
    <label>Safety Stock (%)<input type="number" value={f.safety_stock_percent} onChange={e=>set('safety_stock_percent',Number(e.target.value))}/></label>
   </div>
   <div className="panel-head demand-head"><h3>Historical / Manual Demand (L per hour)</h3><span className="muted">Add up to 6 starting observations</span></div>
   <div className="demand-inputs">{f.demand_points.map((p:any,i:number)=><label key={i}>H{i+1}<input type="number" value={p.demand_liters} onChange={e=>setPoint(i,e.target.value)}/></label>)}</div>
   <button className="primary" onClick={run} disabled={busy}>{busy?'Analyzing…':'Run Forecast & Decision Analysis'}</button>
  </div>
  {r&&<><div className="grid metrics">
    <div className="metric"><span>FORECAST DEMAND</span><strong>{r.total_forecast_liters.toLocaleString()} L</strong><small>{r.average_demand_per_hour.toLocaleString()} L/hour average</small></div>
    <div className="metric"><span>PROJECTED END STORAGE</span><strong>{r.projected_end_storage_liters.toLocaleString()} L</strong><small>of {r.storage_capacity_liters.toLocaleString()} L</small></div>
    <div className="metric"><span>STOCKOUT</span><strong>{r.stockout_hours?`${r.stockout_hours} h`:'Not within horizon'}</strong><small>{r.safety_threshold_hours?`Safety threshold: ${r.safety_threshold_hours}h`:'Above safety stock'}</small></div>
    <div className={'metric '+(r.risk==='CRITICAL'?'danger':r.risk==='HIGH'?'warn':'')}><span>RISK / CONFIDENCE</span><strong>{r.risk}</strong><small>{(r.confidence*100).toFixed(0)}% model confidence</small></div>
   </div>
   <div className="two">
    <div className="panel chart-panel"><div className="panel-head"><div><span className="eyebrow">DEMAND FORECAST</span><h2>Expected consumption by hour</h2></div><span className="status">{r.model}</span></div><ResponsiveContainer width="100%" height={300}><LineChart data={r.chart}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="hour"/><YAxis/><Tooltip/><Legend/><Line type="monotone" dataKey="demand" name="Forecast L/h" strokeWidth={3}/></LineChart></ResponsiveContainer></div>
    <div className="panel chart-panel"><div className="panel-head"><div><span className="eyebrow">STORAGE PREDICTION</span><h2>Inventory trajectory</h2></div></div><ResponsiveContainer width="100%" height={300}><LineChart data={r.chart}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="hour"/><YAxis/><Tooltip/><Legend/><Line type="monotone" dataKey="storage" name="Projected Storage"/><Line type="monotone" dataKey="safety_stock" name="Safety Stock" strokeDasharray="5 5"/></LineChart></ResponsiveContainer></div>
   </div>
   <div className="panel"><div className="panel-head"><div><span className="eyebrow">EXPLAINABLE DECISION ENGINE</span><h2>Recommended action</h2></div><span className={'risk '+r.risk.toLowerCase()}>{r.risk}</span></div>
    <div className="impact"><div><small>Recommended refill</small><strong>{r.recommended_refill_liters.toLocaleString()} L</strong></div><div><small>Forecast horizon</small><strong>{r.horizon_hours} h</strong></div><div><small>Current storage</small><strong>{r.current_storage_liters.toLocaleString()} L</strong></div></div>
    <div className="why"><b>Why</b>{r.explanation.map((x:string,i:number)=><span key={i}>✓ {x}</span>)}</div>
    <div className="rec-actions"><button>Reject / Re-plan</button><button className="primary" onClick={()=>alert('Human approval recorded locally. Simulator allocation is only executed from simulator-backed recommendations.')}>Approve Decision</button></div>
   </div>
  </>}
 </div>
}
