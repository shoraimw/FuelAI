import { useState } from 'react';
import { post, put, del } from '../lib/api';
import { useApi, useAction } from '../lib/hooks';
import Notice from '../components/Notice';

const FUELS = ['DIESEL', 'PETROL', 'OCTANE'];

export default function Transport() {
  const routes = useApi('/api/transport/routes'), veh = useApi('/api/transport/vehicles'), ov = useApi('/api/state/overview', 15000);
  const reload = () => { routes.reload(); veh.reload(); };
  const { msg, run } = useAction(reload);
  const [rc, setRc] = useState<any>({ route_id: '', blocked: false, max_load_liters: '', extra_delay_ticks: 0, reason: '' });
  const [nv, setNv] = useState<any>({ name: '', capacity_liters: 10000, depot_id: '', fuel_types: FUELS });
  const [pl, setPl] = useState<any>({ route_id: '', fuel_type: 'DIESEL', quantity: 2000 });
  const [plan, setPlan] = useState<any>();
  const depots: any[] = ov.data?.depots || [];
  const edit = (r: any) => setRc({ route_id: r.id, blocked: r.constraint?.blocked || false, max_load_liters: r.constraint?.max_load_liters ?? '', extra_delay_ticks: r.constraint?.extra_delay_ticks || 0, reason: r.constraint?.reason || '' });
  const saveRc = () => run(() => put(`/api/transport/routes/${rc.route_id}/constraints`, { blocked: rc.blocked, max_load_liters: rc.max_load_liters === '' ? null : Number(rc.max_load_liters), extra_delay_ticks: Number(rc.extra_delay_ticks), reason: rc.reason || null }), 'Route constraint saved');
  const doPlan = async () => { try { setPlan(await post('/api/transport/plan', { ...pl, quantity: Number(pl.quantity) })); } catch (e: any) { setPlan({ error: e.message }); } };
  return <>
    <Notice msg={msg} error={routes.error || veh.error} />
    <div className="panel"><div className="panel-head"><div><span className="eyebrow">TRANSPORT ROUTES</span><h2>Routes & travel constraints</h2></div><span className="muted">GET /api/transport/routes</span></div>
      <div className="table-wrap"><table><thead><tr><th>Route</th><th>Travel time</th><th>Max load</th><th>Status</th><th>Vehicles</th><th></th></tr></thead><tbody>
        {(routes.data || []).map((r: any) => <tr key={r.id}><td><b>{r.source_depot_name}</b> → {r.destination_station_name}<br /><small>{r.id}</small></td>
          <td>{r.transit_ticks} ticks · {r.travel_minutes} min{r.extra_delay_ticks > 0 && <small> (+{r.extra_delay_ticks} delay)</small>}</td>
          <td>{r.max_shipment.toLocaleString()} L{r.max_shipment !== r.sim_max_shipment && <small> (sim {r.sim_max_shipment.toLocaleString()})</small>}</td>
          <td><span className={'risk ' + (r.blocked ? 'critical' : 'low')}>{r.blocked ? 'BLOCKED' : 'OPEN'}</span>{r.block_reasons.map((x: string, i: number) => <small key={i}><br />{x}</small>)}</td>
          <td>{r.vehicles_available}</td><td><button onClick={() => edit(r)}>Constraints</button></td></tr>)}
      </tbody></table></div>
      {rc.route_id && <><h3 className="sub">Edit constraints · {rc.route_id}</h3><div className="analysis-form">
        <label>Blocked<select value={String(rc.blocked)} onChange={e => setRc({ ...rc, blocked: e.target.value === 'true' })}><option value="false">No</option><option value="true">Yes (closed)</option></select></label>
        <label>Max load per shipment (L)<input type="number" value={rc.max_load_liters} onChange={e => setRc({ ...rc, max_load_liters: e.target.value })} placeholder="no limit" /></label>
        <label>Extra delay (ticks)<input type="number" min={0} value={rc.extra_delay_ticks} onChange={e => setRc({ ...rc, extra_delay_ticks: e.target.value })} /></label>
        <label>Reason<input value={rc.reason} onChange={e => setRc({ ...rc, reason: e.target.value })} placeholder="flood, checkpoint…" /></label></div>
        <div className="actions"><button className="primary" onClick={saveRc}>Save</button><button onClick={() => run(() => del(`/api/transport/routes/${rc.route_id}/constraints`), 'Constraint removed')}>Remove constraint</button><button onClick={() => setRc({ ...rc, route_id: '' })}>Close</button></div></>}
    </div>

    <div className="panel"><div className="panel-head"><div><span className="eyebrow">SHIPMENT PLANNER</span><h2>Check a shipment (dry run)</h2></div><span className="muted">POST /api/transport/plan</span></div>
      <div className="analysis-form">
        <label>Route<select value={pl.route_id} onChange={e => setPl({ ...pl, route_id: e.target.value })}><option value="">Select…</option>{(routes.data || []).map((r: any) => <option key={r.id} value={r.id}>{r.id}</option>)}</select></label>
        <label>Fuel<select value={pl.fuel_type} onChange={e => setPl({ ...pl, fuel_type: e.target.value })}>{FUELS.map(f => <option key={f}>{f}</option>)}</select></label>
        <label>Quantity (L)<input type="number" value={pl.quantity} onChange={e => setPl({ ...pl, quantity: e.target.value })} /></label></div>
      <div className="actions"><button className="primary" disabled={!pl.route_id} onClick={doPlan}>Check feasibility</button></div>
      {plan && (plan.error ? <div className="notice bad">{plan.error}</div> : <div className={'notice ' + (plan.feasible ? 'good' : 'bad')}>
        <b>{plan.feasible ? 'FEASIBLE' : 'NOT FEASIBLE'}</b>{plan.errors.length > 0 && ` · ${plan.errors.join(', ')}`}<br />
        ETA: tick {plan.eta.arrival_tick} ({plan.eta.travel_minutes} min) · trips: {plan.fleet.trips_required ?? 'n/a'} · vehicles: {plan.fleet.available_vehicles.length} · station after delivery: {plan.after_delivery.station_fill_percent}%
        {plan.warnings.map((w: string, i: number) => <div key={i}>⚠ {w}</div>)}</div>)}
    </div>

    <div className="panel"><div className="panel-head"><div><span className="eyebrow">FLEET</span><h2>Transport vehicles</h2></div><span className="muted">GET/POST/PUT/DELETE /api/transport/vehicles</span></div>
      <div className="table-wrap"><table><thead><tr><th>Vehicle</th><th>Depot</th><th>Capacity</th><th>Fuels</th><th>Status</th><th></th></tr></thead><tbody>
        {(veh.data || []).map((v: any) => <tr key={v.id}><td><b>{v.name}</b><br /><small>{v.id}</small></td><td>{v.depot_id}</td><td>{v.capacity_liters.toLocaleString()} L</td><td>{v.fuel_types.join(', ')}</td>
          <td><select value={v.status} onChange={e => run(() => post(`/api/transport/vehicles/${v.id}/status`, { status: e.target.value }), 'Vehicle status updated')}><option>AVAILABLE</option><option>IN_TRANSIT</option><option>MAINTENANCE</option><option>OFFLINE</option></select></td>
          <td><button onClick={() => run(() => del(`/api/transport/vehicles/${v.id}`), 'Vehicle deleted')}>Delete</button></td></tr>)}
      </tbody></table></div>
      <h3 className="sub">Add vehicle</h3><div className="analysis-form">
        <label>Name<input value={nv.name} onChange={e => setNv({ ...nv, name: e.target.value })} /></label>
        <label>Capacity (L)<input type="number" value={nv.capacity_liters} onChange={e => setNv({ ...nv, capacity_liters: e.target.value })} /></label>
        <label>Depot<select value={nv.depot_id} onChange={e => setNv({ ...nv, depot_id: e.target.value })}><option value="">—</option>{depots.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select></label></div>
      <div className="actions"><button className="primary" disabled={!nv.name} onClick={() => run(() => post('/api/transport/vehicles', { name: nv.name, capacity_liters: Number(nv.capacity_liters), depot_id: nv.depot_id || null, fuel_types: nv.fuel_types }), 'Vehicle added').then(() => setNv({ ...nv, name: '' }))}>Add vehicle</button></div>
    </div>
  </>;
}
