export default function Notice({ msg, error }: { msg?: { ok: boolean; text: string } | null; error?: string }) {
  if (error) return <div className="notice bad">API error: {error} — backend 8001 port e cholche?</div>;
  if (!msg) return null;
  return <div className={'notice ' + (msg.ok ? 'good' : 'bad')}>{msg.text}</div>;
}
