export const API:string=(import.meta as any).env?.VITE_API_URL||'';
export async function api<T=any>(path:string,options:RequestInit={}):Promise<T>{const r=await fetch(API+path,{headers:{'Content-Type':'application/json',...(options.headers||{})},...options});if(!r.ok){let d:any={};try{d=await r.json()}catch{}throw new Error(d?.detail?.message||d?.detail||d?.message||`HTTP ${r.status}`)}return r.json()}
export const post=(path:string,body:any={})=>api(path,{method:'POST',body:JSON.stringify(body)});
export const put=(path:string,body:any={})=>api(path,{method:'PUT',body:JSON.stringify(body)});
export const del=(path:string)=>api(path,{method:'DELETE'});
