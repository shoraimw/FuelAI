import { useCallback, useEffect, useState } from 'react';
import { api } from './api';

/** GET a path now and every `ms` milliseconds. */
export function useApi<T = any>(path: string, ms = 6000) {
  const [data, setData] = useState<T | undefined>();
  const [error, setError] = useState('');
  const reload = useCallback(async () => {
    try { setData(await api<T>(path)); setError(''); } catch (e: any) { setError(e.message || 'Request failed'); }
  }, [path]);
  useEffect(() => { reload(); const t = setInterval(reload, ms); return () => clearInterval(t); }, [reload, ms]);
  return { data, error, reload };
}

/** Run an API action, show ok/error text, then refresh. */
export function useAction(after: () => void) {
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const run = async (fn: () => Promise<any>, okText = 'Saved') => {
    try { await fn(); setMsg({ ok: true, text: okText }); after(); } catch (e: any) { setMsg({ ok: false, text: e.message || 'Failed' }); }
  };
  return { msg, run, clear: () => setMsg(null) };
}
