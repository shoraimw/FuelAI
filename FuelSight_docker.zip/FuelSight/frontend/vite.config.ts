import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
const target='http://127.0.0.1:8001';
export default defineConfig({
  plugins:[react()],
  server:{port:5173,host:'127.0.0.1',proxy:{'/api':{target,changeOrigin:true},'/metrics':{target,changeOrigin:true},'/docs':{target,changeOrigin:true},'/openapi.json':{target,changeOrigin:true}}}
});
