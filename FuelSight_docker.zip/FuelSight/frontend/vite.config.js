import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
var target = 'http://127.0.0.1:8001';
export default defineConfig({
    plugins: [react()],
    server: { port: 5173, host: '127.0.0.1', proxy: { '/api': { target: target, changeOrigin: true }, '/metrics': { target: target, changeOrigin: true }, '/docs': { target: target, changeOrigin: true }, '/openapi.json': { target: target, changeOrigin: true } } }
});
