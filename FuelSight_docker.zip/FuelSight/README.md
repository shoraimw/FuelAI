# FuelSight — Fuel Supply Intelligence & Resilience Platform

A native Windows-friendly, **no-Docker application** for the BUP Fuel Supply Simulator.

The platform implements:

**Observe → Detect → Predict → Decide → Simulate → Act → Monitor → Recover**

## Included

- React + Vite + TypeScript operator dashboard
- FastAPI backend
- SQLite persistence
- Background simulator collector
- REST polling + SSE-ready stream layer
- Retry/backoff + circuit breaker + stale-data detection
- Demand forecasting: hour-of-day baseline + exponential smoothing
- Hours-to-stockout risk
- Demand anomaly detection
- Greedy route-aware allocation recommendations
- Human approval before `POST /v1/allocations`
- Constraint pre-checks
- What-if impact calculation
- Scenario/fault controls
- Prometheus metrics
- k6 load-test script
- Pytest tests
- Windows CMD setup/start scripts
- Optional `MOCK_MODE=true` for development without the simulator

## Source basis

The supplied BUP brief requires an operator-facing application, backend, intelligence capability, deployment, observability, resilience and load testing. It also asks the application to expose inventory, depot/station status, shortage risk, supply, disruptions, recommended allocations, decision impact, alerts, history and service health.

The supplied integration guide defines the simulator as the operational world and says REST is the source of truth, SSE is a notification stream, and `POST /v1/allocations` is the participant domain write.

## Requirements

Windows 10/11, Python 3.11+, Node.js 20+, npm. k6 is optional.

## Windows CMD setup

From the project root:

```cmd
copy .env.example .env
scripts\setup.cmd
```

Then start the backend:

```cmd
scripts\start_backend.cmd
```

Open a second CMD and start the frontend:

```cmd
scripts\start_frontend.cmd
```

Open:

http://127.0.0.1:5173

Backend Swagger:

http://127.0.0.1:8001/docs

Metrics:

http://127.0.0.1:8001/metrics

## Connect the official simulator

The official simulator normally runs separately and exposes port 8000. Keep:

```env
SIMULATOR_URL=http://127.0.0.1:8000
MOCK_MODE=false
```

FuelSight itself uses no Docker.

If you do not have the simulator running yet, set:

```env
MOCK_MODE=true
```

Then restart the backend. Mock mode gives you a small local operational world for UI/demo development; switch back to `false` for the real hackathon simulator.

## Simulator API handling

FuelSight reads the simulator state through `/v1/instance`, `/v1/regions`, `/v1/depots`, `/v1/stations`, `/v1/routes`, `/v1/supply-arrivals`, `/v1/events`, `/v1/allocations`, `/v1/demand-history` and `/v1/metrics`.

The client sends allocation decisions through `POST /v1/allocations`.

Important integration behavior is implemented:

- bounded demand-history requests
- response stale-data detection
- retry/backoff for transient 503/502/504 and request failures
- circuit breaker
- unique idempotency keys
- pre-submit route/inventory/capacity checks
- degraded system status
- cached SQLite state when simulator calls fail
- human approval before an allocation is submitted

## Demo flow

1. Dashboard → show service level and current risks.
2. Scenarios → step ticks.
3. Inject Dhaka demand spike ×1.8.
4. Dashboard/Alerts → show risk/anomaly.
5. Recommendations → Generate.
6. Inspect explanation, confidence, route and constraints.
7. Approve & Send.
8. Inject route disruption → generate again.
9. Inject simulator error/unavailable/stale fault.
10. System Status → show degraded mode and circuit breaker.
11. Clear faults → show recovery.
12. Run k6.

## Project structure

```text
FuelSight/
├─ backend/
│  ├─ app/
│  │  ├─ api/
│  │  ├─ core/
│  │  ├─ db/
│  │  ├─ decision/
│  │  ├─ intelligence/
│  │  ├─ observability/
│  │  ├─ simulator/
│  │  ├─ main.py
│  │  └─ state.py
│  ├─ tests/
│  └─ requirements.txt
├─ frontend/
│  ├─ src/
│  ├─ package.json
│  └─ vite.config.ts
├─ docs/
├─ loadtest/
├─ monitoring/
├─ scripts/
└─ .github/workflows/
```

## Native deployment

The intended hackathon deployment is simply:

```cmd
scripts\setup.cmd
scripts\start_backend.cmd
scripts\start_frontend.cmd
```

No Docker is required for FuelSight.

For a permanent Windows server, the backend can be installed as a Windows service and the frontend production build can be served by IIS. That is optional.

## Test

```cmd
scripts
un_tests.cmd
```

## Load test

Install k6 on the Windows machine, start FuelSight, then:

```cmd
scripts
un_loadtest.cmd
```

The included script measures a representative read path and reports average/p95/p99 latency, throughput and error rate through k6.

## Architecture

```text
                BUP Fuel Supply Simulator
                  REST /v1/* + SSE
                         |
                         v
               +--------------------+
               | Simulator Client   |
               | retry/backoff      |
               | circuit breaker    |
               | stale detection     |
               +---------+----------+
                         |
                         v
               +--------------------+
               | Collector / Cache  |
               +---------+----------+
                         |
              +----------+----------+
              |                     |
              v                     v
       Intelligence            SQLite/Audit
   Forecast / Risk / Anomaly
              |
              v
       Decision Engine
   Constraints / Greedy / What-if
              |
              v
      Human Approval UI
              |
              v
       POST /v1/allocations

React Operator UI <-> FastAPI
Prometheus <---------- /metrics
k6 ------------------> FastAPI
```

## Notes

The predictor is intentionally explainable. The challenge's simulator provides deterministic demand profiles, and the supplied brief emphasizes a working system rather than ML accuracy alone. The architecture therefore prioritizes operational reliability, transparent decisions, resilience and observability.

The project does not modify the official simulator.


## New: Manual Analysis & Forecasting
Open **Analysis & Forecast** from the sidebar. Enter region (Dhaka/Chattogram), depot/station, fuel, time horizon, hourly demand observations, current storage, capacity, incoming supply, growth and demand multiplier. The dependency-free FuelSight Ensemble Demand Model produces demand forecasts, storage trajectories, stockout/safety thresholds, risk, confidence and an explainable refill recommendation. Charts use Recharts. Manual analysis never overwrites the simulator; simulator allocations still require human approval.
