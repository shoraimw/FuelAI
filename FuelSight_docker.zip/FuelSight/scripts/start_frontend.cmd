@echo off
cd /d "%~dp0..\frontend"
if not exist "node_modules" (echo Run scripts\setup.cmd first.&exit /b 1)
npm run dev
