@echo off
cd /d "%~dp0.."
if not exist ".env" copy ".env.example" ".env" >nul
if not exist ".venv\Scripts\python.exe" (echo Run scripts\setup.cmd first.&exit /b 1)
".venv\Scripts\python.exe" -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8001 --reload --reload-dir backend
