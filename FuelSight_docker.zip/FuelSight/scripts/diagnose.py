"""Connection checker: python scripts/diagnose.py"""
import json, urllib.request
def get(url, headers=None):
    try:
        r = urllib.request.urlopen(urllib.request.Request(url, headers=headers or {}), timeout=4)
        return r.status, dict(r.headers), r.read().decode()
    except Exception as e:
        return None, {}, str(e)
def line(ok, msg): print(("[ OK ] " if ok else "[FAIL] ") + msg)
s, _, b = get("http://127.0.0.1:8001/api/health")
line(s == 200, f"Backend 8001 /api/health -> {s} {b[:120] if s else b}")
if s == 200:
    h = json.loads(b); line(h.get("simulator") == "healthy", f"mode={h.get('mode')} simulator={h.get('simulator')} breaker={h.get('circuit_breaker')}")
    s, hd, b = get("http://127.0.0.1:8001/api/state/overview", {"Origin": "http://127.0.0.1:5173"})
    d = json.loads(b) if s == 200 else {}
    line(len(d.get("stations", [])) > 0, f"stations={len(d.get('stations', []))} tick={d.get('instance', {}).get('tick')}")
    line(hd.get("access-control-allow-origin") == "http://127.0.0.1:5173", "CORS header for http://127.0.0.1:5173")
s, _, b = get("http://127.0.0.1:5173/api/health")
line(s == 200, f"Frontend proxy 5173 -> /api/health -> {s}")
s, _, b = get("http://127.0.0.1:8000/v1/health")
line(s == 200, f"Real simulator 8000 /v1/health -> {s} (FAIL hole mock fallback use hobe)")
