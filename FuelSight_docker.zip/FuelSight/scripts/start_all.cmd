@echo off
cd /d "%~dp0.."
start "FuelSight Backend" cmd /k scripts\start_backend.cmd
timeout /t 4 >nul
start "FuelSight Frontend" cmd /k scripts\start_frontend.cmd
timeout /t 6 >nul
start http://127.0.0.1:5173
