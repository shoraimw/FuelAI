@echo off
setlocal
cd /d "%~dp0.."
echo [1/4] Creating Python virtual environment...
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
if errorlevel 1 goto python_error
echo [2/4] Installing backend packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r backend\requirements.txt
if errorlevel 1 goto pip_error
echo [3/4] Installing frontend packages...
cd frontend
call npm install
if errorlevel 1 goto npm_error
cd ..
echo [4/4] Creating .env...
if not exist ".env" copy ".env.example" ".env" >nul
echo Setup complete.
exit /b 0
:python_error
echo Python 3.11+ was not found.
exit /b 1
:pip_error
echo Backend installation failed.
exit /b 1
:npm_error
echo npm install failed. Install Node.js 20+.
exit /b 1
