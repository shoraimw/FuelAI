@echo off
cd /d "%~dp0.."
".venv\Scripts\python.exe" -m pytest backend\tests -q
