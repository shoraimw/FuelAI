@echo off
echo Requires k6 and a running FuelSight backend.
k6 run loadtest\k6_decision_api.js
