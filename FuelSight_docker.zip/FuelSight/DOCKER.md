# FuelSight on Docker (Linux)

    chmod +x run.sh
    ./run.sh                    # build, start, and self-test everything
    ./run.sh --install-docker   # same, but installs Docker first if missing

Open http://localhost:5173 (API docs: http://localhost:8001/docs).

| Command | What it does |
|---|---|
| `./run.sh up` | build + start + smoke tests (default) |
| `./run.sh status` | show containers and re-run smoke tests |
| `./run.sh logs` | follow logs |
| `./run.sh test` | run backend pytest suite in a container |
| `./run.sh monitoring` | add Prometheus on :9090 |
| `./run.sh down` | stop (database kept) |
| `./run.sh reset` | stop and delete database volume |

Options: `--mock` (default, built-in simulator data), `--real-simulator`
(uses the BUP simulator on the host at :8000, falls back to mock if unreachable).

Ports/settings live in `.env.docker` (auto-created; ports auto-shift if 5173/8001 are busy).

Architecture: browser -> nginx (frontend container, :5173) -> `/api`, `/metrics`, `/docs`
proxied to FastAPI (backend container, :8001) -> SQLite in the `fuelsight-data` volume.
