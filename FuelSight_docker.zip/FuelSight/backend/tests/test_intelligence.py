from app.intelligence.forecast import forecast
from app.intelligence.risk import risk_for
def test_forecast_and_risk():
    st={"id":"station-tongi","demand_profile":"industrial","demand_multiplier":1.0,"inventory":{"DIESEL":11000}}
    f=forecast([],st,"DIESEL",24);r=risk_for(st,"DIESEL",f)
    assert len(f["hourly_liters"])==24 and r["hours_to_stockout"]>0 and r["risk"] in {"CRITICAL","HIGH","MEDIUM","LOW"}
