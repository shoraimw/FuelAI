from app.decision.constraints import validate_candidate
def test_route_capacity():
    d=[{"id":"d","status":"OPEN","inventory":{"DIESEL":10000},"dispatch_capacity_per_tick":12000}]
    s=[{"id":"s","status":"OPEN","inventory":{"DIESEL":0},"capacity":{"DIESEL":10000}}]
    r=[{"id":"r","source_depot_id":"d","destination_station_id":"s","status":"AVAILABLE","max_shipment":1000}]
    assert "ROUTE_CAPACITY_EXCEEDED" in validate_candidate({"source_depot_id":"d","destination_station_id":"s","route_id":"r","fuel_type":"DIESEL","quantity":2000},d,s,r)
