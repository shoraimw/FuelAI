import os, tempfile, pytest
os.environ["MOCK_MODE"] = "true"
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "test.db")
from fastapi.testclient import TestClient

@pytest.fixture(scope="session")
def client():
    from app.main import app
    with TestClient(app) as c:
        import time
        for _ in range(50):
            if c.get("/api/state/overview").json().get("stations"): break
            time.sleep(.2)
        yield c
