def test_inventory(client):
    st = client.get("/api/inventory/stations").json()
    assert len(st) == 4 and st[0]["fuels"][0]["fill_percent"] > 0
    assert client.get("/api/inventory/depots").json()[0]["vehicles_total"] >= 2
    sm = client.get("/api/inventory/summary").json()
    assert set(sm["fuels"]) == {"DIESEL", "PETROL", "OCTANE"}
    assert len(client.get("/api/stations?region_id=region-dhaka").json()) == 2

def test_station_status_override(client):
    r = client.post("/api/stations/station-tongi/status", json={"status": "CLOSED", "reason": "test"}).json()
    assert r["status"] == "CLOSED" and r["status_source"] == "operator"
    plan = client.post("/api/transport/plan", json={"route_id": "route-gazipur-tongi", "fuel_type": "DIESEL", "quantity": 1000}).json()
    assert not plan["feasible"] and "STATION_CLOSED" in plan["errors"]
    assert client.delete("/api/stations/station-tongi/status").json()["status"] == "OPEN"
    assert client.post("/api/stations/nope/status", json={"status": "OPEN"}).status_code == 404
    assert client.post("/api/stations/station-tongi/status", json={"status": "WEIRD"}).status_code == 422

def test_regional_demand(client):
    base = client.get("/api/regions/region-dhaka/demand").json()
    assert len(base["hourly_forecast"]) == 24 and base["stations"] == 2
    up = client.post("/api/regions/region-dhaka/demand-override", json={"multiplier": 2.0, "note": "eid"}).json()
    assert up["total_forecast_liters_per_hour"] > base["total_forecast_liters_per_hour"] * 1.8
    assert len(client.get("/api/regions/demand").json()["regions"]) == 2
    client.delete("/api/regions/region-dhaka/demand-override")
    assert client.post("/api/regions/x/demand-override", json={"multiplier": 2}).status_code == 404
    assert client.post("/api/regions/region-dhaka/demand-override", json={"multiplier": 0}).status_code == 422

def test_vehicles_crud(client):
    v = client.post("/api/transport/vehicles", json={"id": "veh-t1", "name": "T1", "capacity_liters": 8000, "depot_id": "depot-gazipur"})
    assert v.status_code == 201
    assert client.post("/api/transport/vehicles", json={"id": "veh-t1", "name": "T1", "capacity_liters": 8000}).status_code == 409
    assert client.put("/api/transport/vehicles/veh-t1", json={"name": "T1b", "capacity_liters": 9000, "depot_id": "depot-gazipur"}).json()["capacity_liters"] == 9000
    assert client.post("/api/transport/vehicles/veh-t1/status", json={"status": "MAINTENANCE"}).json()["status"] == "MAINTENANCE"
    assert client.post("/api/transport/vehicles", json={"name": "bad", "capacity_liters": 1, "depot_id": "zzz"}).status_code == 422
    assert client.delete("/api/transport/vehicles/veh-t1").status_code == 200
    assert client.get("/api/transport/vehicles/veh-t1").status_code == 404

def test_route_constraints_and_plan(client):
    r0 = client.get("/api/transport/routes/route-gazipur-mirpur").json()
    c = client.put("/api/transport/routes/route-gazipur-mirpur/constraints", json={"max_load_liters": 2000, "extra_delay_ticks": 3, "reason": "flood"}).json()
    assert c["max_shipment"] == 2000 and c["transit_ticks"] == r0["transit_ticks"] + 3 and c["travel_minutes"] == c["transit_ticks"] * 15
    p = client.post("/api/transport/plan", json={"route_id": "route-gazipur-mirpur", "fuel_type": "DIESEL", "quantity": 3000}).json()
    assert "ROUTE_CAPACITY_EXCEEDED" in p["errors"]
    ok = client.post("/api/transport/plan", json={"route_id": "route-gazipur-mirpur", "fuel_type": "DIESEL", "quantity": 1500}).json()
    assert ok["feasible"] and ok["eta"]["transit_ticks"] == c["transit_ticks"] and ok["fleet"]["trips_required"] == 1
    client.put("/api/transport/routes/route-gazipur-mirpur/constraints", json={"blocked": True, "reason": "closed"})
    assert "ROUTE_DISRUPTED" in client.post("/api/transport/plan", json={"route_id": "route-gazipur-mirpur", "fuel_type": "DIESEL", "quantity": 500}).json()["errors"]
    assert len(client.get("/api/transport/routes?blocked=true").json()) == 1
    client.delete("/api/transport/routes/route-gazipur-mirpur/constraints")
    assert client.get("/api/transport/routes/route-gazipur-mirpur").json()["blocked"] is False
    assert client.put("/api/transport/routes/nope/constraints", json={}).status_code == 404

def test_fleet_blocks_when_no_vehicle(client):
    for v in client.get("/api/transport/vehicles?depot_id=depot-patiya").json():
        client.post(f"/api/transport/vehicles/{v['id']}/status", json={"status": "MAINTENANCE"})
    p = client.post("/api/transport/plan", json={"route_id": "route-patiya-coxsbazar", "fuel_type": "PETROL", "quantity": 500}).json()
    assert "NO_VEHICLE_AVAILABLE" in p["errors"]
    for v in client.get("/api/transport/vehicles?depot_id=depot-patiya").json():
        client.post(f"/api/transport/vehicles/{v['id']}/status", json={"status": "AVAILABLE"})

def test_supply_delays(client):
    assert client.post("/api/supply/delays", json={"delay_ticks": 4}).status_code == 422
    d = client.post("/api/supply/delays", json={"depot_id": "depot-gazipur", "fuel_type": "DIESEL", "delay_ticks": 6, "reason": "port strike"})
    assert d.status_code == 201 and d.json()["status"] == "ACTIVE"
    assert client.post("/api/supply/delays", json={"arrival_id": 999, "delay_ticks": 2}).status_code == 404
    assert client.get("/api/supply/arrivals").json()["summary"]["total"] == 0  # mock has no arrivals
    assert client.post(f"/api/supply/delays/{d.json()['id']}/resolve").json()["status"] == "RESOLVED"
    assert client.delete(f"/api/supply/delays/{d.json()['id']}").status_code == 200

def test_supply_arrival_shift(client):
    from app.main import app
    fs = app.state.fs; fs.cache["supply-arrivals"] = [{"id": 7, "depot_id": "depot-gazipur", "fuel_type": "DIESEL", "quantity": 20000, "planned_tick": 50, "status": "SCHEDULED"}]
    d = client.post("/api/supply/delays", json={"arrival_id": 7, "delay_ticks": 5}).json()
    a = client.get("/api/supply/arrivals").json()
    assert a["arrivals"][0]["effective_tick"] == 55 and a["summary"]["delayed_liters"] == 20000
    client.post(f"/api/supply/delays/{d['id']}/resolve")
    assert client.get("/api/supply/arrivals").json()["arrivals"][0]["effective_tick"] == 50

def test_crisis_lifecycle(client):
    base = client.get("/api/risk").json()
    assert client.post("/api/crises", json={"type": "ROUTE_DISRUPTION", "title": "x"}).status_code == 422
    assert client.post("/api/crises", json={"type": "DEMAND_SPIKE", "title": "x", "region_id": "nope"}).status_code == 422
    c = client.post("/api/crises", json={"type": "DEMAND_SPIKE", "severity": "HIGH", "title": "Eid rush", "region_id": "region-dhaka", "demand_multiplier": 2.5, "duration_ticks": 40}).json()
    assert c["state"] == "ACTIVE" and c["forwarded"] is False
    after = client.get("/api/risk").json()
    b = next(x for x in base if x["station_id"] == "station-mirpur" and x["fuel_type"] == "PETROL")
    a = next(x for x in after if x["station_id"] == "station-mirpur" and x["fuel_type"] == "PETROL")
    assert a["forecast_demand_per_hour"] > b["forecast_demand_per_hour"] * 2
    lv = client.get("/api/crises/level").json()
    assert lv["active_crises"] >= 1 and lv["level"] in ("ELEVATED", "SEVERE", "CRITICAL")
    assert client.get(f"/api/crises/{c['id']}").json()["ends_at_tick"] == c["start_tick"] + 40
    assert client.post(f"/api/crises/{c['id']}/resolve").json()["state"] == "RESOLVED"
    assert client.get("/api/crises?status=ACTIVE").json() == []
    assert client.delete(f"/api/crises/{c['id']}").status_code == 200
    assert client.get("/api/crises/9999").status_code == 404

def test_crisis_route_and_station_effects_and_forward(client):
    c = client.post("/api/crises", json={"type": "STATION_CLOSURE", "severity": "CRITICAL", "title": "fire", "station_ids": ["station-mirpur"]}).json()
    assert next(x for x in client.get("/api/stations").json() if x["id"] == "station-mirpur")["status"] == "CLOSED"
    client.post(f"/api/crises/{c['id']}/resolve")
    f = client.post("/api/crises", json={"type": "ROUTE_DISRUPTION", "title": "bridge", "route_ids": ["route-patiya-karnaphuli"], "forward_to_simulator": True, "duration_ticks": 20}).json()
    assert f["forwarded"] is True and f["forward_error"] is None
    assert client.get("/api/transport/routes/route-patiya-karnaphuli").json()["blocked"] is True
    client.post(f"/api/crises/{f['id']}/resolve")
    ds = client.post("/api/crises", json={"type": "DEPOT_OUTAGE", "title": "power", "depot_ids": ["depot-gazipur"]}).json()
    assert next(d for d in client.get("/api/depots").json() if d["id"] == "depot-gazipur")["status"] == "CLOSED"
    client.post(f"/api/crises/{ds['id']}/resolve")

def test_recommendation_respects_constraints(client):
    client.put("/api/transport/routes/route-gazipur-tongi/constraints", json={"blocked": True})
    recs = client.post("/api/recommendations/generate").json()["recommendations"]
    assert all(r["allocation"]["route_id"] != "route-gazipur-tongi" for r in recs)
    client.delete("/api/transport/routes/route-gazipur-tongi/constraints")
