"""Pure functions: apply operator data + crises on top of the simulator snapshot."""
CRISIS_TYPES = ["DEMAND_SPIKE", "ROUTE_DISRUPTION", "DEPOT_OUTAGE", "STATION_CLOSURE", "SUPPLY_DELAY", "FUEL_SHORTAGE", "OTHER"]
SEVERITY_RANK = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

def crisis_state(c, tick):
    """ACTIVE / SCHEDULED / EXPIRED / RESOLVED, computed against the simulator tick."""
    if c["status"] == "RESOLVED":
        return "RESOLVED"
    start = c.get("start_tick") or 0
    if tick < start:
        return "SCHEDULED"
    dur = c.get("duration_ticks")
    if dur is not None and tick >= start + dur:
        return "EXPIRED"
    return "ACTIVE"

def with_state(crises, tick):
    return [{**c, "state": crisis_state(c, tick), "ends_at_tick": (c["start_tick"] + c["duration_ticks"]) if c.get("duration_ticks") is not None else None} for c in crises]

def active(crises, tick):
    return [c for c in with_state(crises, tick) if c["state"] == "ACTIVE"]

def effects(crises, tick):
    """Aggregate what active crises do. Forwarded demand/route events are already reflected by the simulator -> not applied twice."""
    e = {"region_mult": {}, "station_mult": {}, "closed_stations": set(), "closed_depots": set(), "blocked_routes": set(), "delay": []}
    for c in active(crises, tick):
        t = c["type"]
        if t == "DEMAND_SPIKE" and not c["forwarded"]:
            m = float(c.get("demand_multiplier") or 1.0)
            if c.get("region_id"):
                e["region_mult"][c["region_id"]] = e["region_mult"].get(c["region_id"], 1.0) * m
            for s in c.get("station_ids", []):
                e["station_mult"][s] = e["station_mult"].get(s, 1.0) * m
        elif t == "ROUTE_DISRUPTION" and not c["forwarded"]:
            e["blocked_routes"].update(c.get("route_ids", []))
        elif t == "DEPOT_OUTAGE":
            e["closed_depots"].update(c.get("depot_ids", []))
        elif t == "STATION_CLOSURE":
            e["closed_stations"].update(c.get("station_ids", []))
        elif t == "SUPPLY_DELAY":
            e["delay"].append({"depot_ids": c.get("depot_ids", []), "fuel_type": c.get("fuel_type"), "delay_ticks": int(c.get("delay_ticks") or 0)})
    return e

def crisis_level(crises, tick, risks):
    """Overall network crisis level = worst of (active crisis severities, live stockout risk)."""
    act = active(crises, tick)
    worst = max([SEVERITY_RANK[c["severity"]] for c in act], default=0)
    critical = sum(1 for r in risks if r["risk"] == "CRITICAL")
    high = sum(1 for r in risks if r["risk"] == "HIGH")
    if critical >= 3: worst = max(worst, 4)
    elif critical >= 1: worst = max(worst, 3)
    elif high >= 1: worst = max(worst, 2)
    level = {0: "NORMAL", 1: "WATCH", 2: "ELEVATED", 3: "SEVERE", 4: "CRITICAL"}[worst]
    return {"level": level, "score": worst, "active_crises": len(act), "critical_risks": critical, "high_risks": high}
