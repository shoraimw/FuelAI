"""Operator-managed data (transport, constraints, delays, crises, overrides).
The official simulator is never modified: everything here is stored in FuelSight's own SQLite DB."""
import json, sqlite3, threading
from datetime import datetime, timezone
from pathlib import Path

def now():
    return datetime.now(timezone.utc).isoformat()

class OpsStore:
    def __init__(self, path: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()
        with self.conn() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS vehicles(
              id TEXT PRIMARY KEY, name TEXT NOT NULL, vehicle_type TEXT DEFAULT 'TANKER',
              capacity_liters REAL NOT NULL, fuel_types TEXT NOT NULL, depot_id TEXT,
              status TEXT DEFAULT 'AVAILABLE', driver TEXT, notes TEXT, updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS route_constraints(
              route_id TEXT PRIMARY KEY, blocked INTEGER DEFAULT 0, max_load_liters REAL,
              extra_delay_ticks INTEGER DEFAULT 0, reason TEXT, updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS supply_delays(
              id INTEGER PRIMARY KEY AUTOINCREMENT, arrival_id TEXT, depot_id TEXT, fuel_type TEXT,
              delay_ticks INTEGER NOT NULL, reason TEXT, status TEXT DEFAULT 'ACTIVE',
              created_at TEXT NOT NULL, resolved_at TEXT);
            CREATE TABLE IF NOT EXISTS crises(
              id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, severity TEXT NOT NULL, title TEXT NOT NULL,
              region_id TEXT, station_ids TEXT, route_ids TEXT, depot_ids TEXT, fuel_type TEXT,
              demand_multiplier REAL DEFAULT 1.0, delay_ticks INTEGER DEFAULT 0,
              start_tick INTEGER DEFAULT 0, duration_ticks INTEGER, status TEXT DEFAULT 'ACTIVE', note TEXT,
              forwarded INTEGER DEFAULT 0, sim_response TEXT, created_at TEXT NOT NULL, resolved_at TEXT);
            CREATE TABLE IF NOT EXISTS status_overrides(
              kind TEXT NOT NULL, id TEXT NOT NULL, status TEXT NOT NULL, reason TEXT, updated_at TEXT NOT NULL,
              PRIMARY KEY(kind,id));
            CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
            CREATE TABLE IF NOT EXISTS region_overrides(
              region_id TEXT PRIMARY KEY, multiplier REAL NOT NULL, note TEXT, updated_at TEXT NOT NULL);
            """)

    def conn(self):
        c = sqlite3.connect(self.path, check_same_thread=False)
        c.row_factory = sqlite3.Row
        return c

    def _all(self, q, args=()):
        with self.conn() as c:
            return [dict(r) for r in c.execute(q, args).fetchall()]

    def _one(self, q, args=()):
        rows = self._all(q, args)
        return rows[0] if rows else None

    def _exec(self, q, args=()):
        with self.lock, self.conn() as c:
            cur = c.execute(q, args)
            return cur.lastrowid

    # ---- vehicles
    @staticmethod
    def _veh(r):
        if r:
            r["fuel_types"] = json.loads(r["fuel_types"])
        return r

    def vehicles(self, depot_id=None, status=None):
        q, a = "SELECT * FROM vehicles WHERE 1=1", []
        if depot_id: q += " AND depot_id=?"; a.append(depot_id)
        if status: q += " AND status=?"; a.append(status)
        return [self._veh(r) for r in self._all(q + " ORDER BY id", a)]

    def vehicle(self, id):
        return self._veh(self._one("SELECT * FROM vehicles WHERE id=?", (id,)))

    def upsert_vehicle(self, v):
        self._exec("""INSERT INTO vehicles(id,name,vehicle_type,capacity_liters,fuel_types,depot_id,status,driver,notes,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,vehicle_type=excluded.vehicle_type,
            capacity_liters=excluded.capacity_liters,fuel_types=excluded.fuel_types,depot_id=excluded.depot_id,status=excluded.status,
            driver=excluded.driver,notes=excluded.notes,updated_at=excluded.updated_at""",
            (v["id"], v["name"], v.get("vehicle_type", "TANKER"), v["capacity_liters"], json.dumps(v["fuel_types"]),
             v.get("depot_id"), v.get("status", "AVAILABLE"), v.get("driver"), v.get("notes"), now()))
        return self.vehicle(v["id"])

    def delete_vehicle(self, id):
        with self.lock, self.conn() as c:
            return c.execute("DELETE FROM vehicles WHERE id=?", (id,)).rowcount > 0

    # ---- route constraints
    def route_constraints(self):
        return {r["route_id"]: {**r, "blocked": bool(r["blocked"])} for r in self._all("SELECT * FROM route_constraints")}

    def set_route_constraint(self, route_id, blocked, max_load, extra_delay, reason):
        self._exec("""INSERT INTO route_constraints(route_id,blocked,max_load_liters,extra_delay_ticks,reason,updated_at)
            VALUES(?,?,?,?,?,?) ON CONFLICT(route_id) DO UPDATE SET blocked=excluded.blocked,max_load_liters=excluded.max_load_liters,
            extra_delay_ticks=excluded.extra_delay_ticks,reason=excluded.reason,updated_at=excluded.updated_at""",
            (route_id, int(blocked), max_load, extra_delay, reason, now()))

    def clear_route_constraint(self, route_id):
        with self.lock, self.conn() as c:
            return c.execute("DELETE FROM route_constraints WHERE route_id=?", (route_id,)).rowcount > 0

    # ---- supply delays
    def supply_delays(self, status=None):
        q, a = "SELECT * FROM supply_delays", []
        if status: q += " WHERE status=?"; a.append(status)
        return self._all(q + " ORDER BY id DESC", a)

    def supply_delay(self, id):
        return self._one("SELECT * FROM supply_delays WHERE id=?", (id,))

    def add_supply_delay(self, arrival_id, depot_id, fuel_type, delay_ticks, reason):
        id = self._exec("INSERT INTO supply_delays(arrival_id,depot_id,fuel_type,delay_ticks,reason,created_at) VALUES(?,?,?,?,?,?)",
                        (arrival_id, depot_id, fuel_type, delay_ticks, reason, now()))
        return self.supply_delay(id)

    def resolve_supply_delay(self, id):
        self._exec("UPDATE supply_delays SET status='RESOLVED',resolved_at=? WHERE id=?", (now(), id))
        return self.supply_delay(id)

    def delete_supply_delay(self, id):
        with self.lock, self.conn() as c:
            return c.execute("DELETE FROM supply_delays WHERE id=?", (id,)).rowcount > 0

    # ---- crises
    @staticmethod
    def _cr(r):
        if r:
            for k in ("station_ids", "route_ids", "depot_ids"):
                r[k] = json.loads(r[k]) if r[k] else []
            r["forwarded"] = bool(r["forwarded"])
            r["sim_response"] = json.loads(r["sim_response"]) if r["sim_response"] else None
        return r

    def crises(self, status=None):
        q, a = "SELECT * FROM crises", []
        if status: q += " WHERE status=?"; a.append(status)
        return [self._cr(r) for r in self._all(q + " ORDER BY id DESC", a)]

    def crisis(self, id):
        return self._cr(self._one("SELECT * FROM crises WHERE id=?", (id,)))

    def add_crisis(self, c):
        id = self._exec("""INSERT INTO crises(type,severity,title,region_id,station_ids,route_ids,depot_ids,fuel_type,demand_multiplier,
            delay_ticks,start_tick,duration_ticks,note,forwarded,sim_response,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (c["type"], c["severity"], c["title"], c.get("region_id"), json.dumps(c.get("station_ids") or []),
             json.dumps(c.get("route_ids") or []), json.dumps(c.get("depot_ids") or []), c.get("fuel_type"),
             c.get("demand_multiplier", 1.0), c.get("delay_ticks", 0), c.get("start_tick", 0), c.get("duration_ticks"),
             c.get("note"), int(c.get("forwarded", False)),
             json.dumps(c["sim_response"]) if c.get("sim_response") is not None else None, now()))
        return self.crisis(id)

    def resolve_crisis(self, id):
        self._exec("UPDATE crises SET status='RESOLVED',resolved_at=? WHERE id=?", (now(), id))
        return self.crisis(id)

    def delete_crisis(self, id):
        with self.lock, self.conn() as c:
            return c.execute("DELETE FROM crises WHERE id=?", (id,)).rowcount > 0

    # ---- status overrides (station/depot open/closed set by operator)
    def status_overrides(self, kind):
        return {r["id"]: r for r in self._all("SELECT * FROM status_overrides WHERE kind=?", (kind,))}

    def set_status_override(self, kind, id, status, reason):
        self._exec("""INSERT INTO status_overrides(kind,id,status,reason,updated_at) VALUES(?,?,?,?,?)
            ON CONFLICT(kind,id) DO UPDATE SET status=excluded.status,reason=excluded.reason,updated_at=excluded.updated_at""",
            (kind, id, status, reason, now()))

    def clear_status_override(self, kind, id):
        with self.lock, self.conn() as c:
            return c.execute("DELETE FROM status_overrides WHERE kind=? AND id=?", (kind, id)).rowcount > 0

    # ---- regional demand overrides
    def region_overrides(self):
        return {r["region_id"]: r for r in self._all("SELECT * FROM region_overrides")}

    def set_region_override(self, region_id, multiplier, note):
        self._exec("""INSERT INTO region_overrides(region_id,multiplier,note,updated_at) VALUES(?,?,?,?)
            ON CONFLICT(region_id) DO UPDATE SET multiplier=excluded.multiplier,note=excluded.note,updated_at=excluded.updated_at""",
            (region_id, multiplier, note, now()))

    def clear_region_override(self, region_id):
        with self.lock, self.conn() as c:
            return c.execute("DELETE FROM region_overrides WHERE region_id=?", (region_id,)).rowcount > 0

    # ---- meta flags
    def get_meta(self, key):
        r = self._one("SELECT value FROM meta WHERE key=?", (key,))
        return r["value"] if r else None

    def set_meta(self, key, value):
        self._exec("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
