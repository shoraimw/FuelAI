import asyncio,json,logging,time
from .core.config import settings
from .db.store import Store
from .simulator.client import SimulatorClient
from .simulator.mock import MockSimulatorClient
from .observability.metrics import SERVICE_LEVEL,SIMULATOR_UP,STALE
from .ops.store import OpsStore
from .ops import effects as fx
FUELS=("DIESEL","PETROL","OCTANE")
log=logging.getLogger("fuelsight.state")
class AppState:
    def __init__(self):
        self.store=Store(settings.db_file);self.ops=OpsStore(settings.db_file);self.mode="mock" if settings.mock_mode else "simulator";self.sim=MockSimulatorClient() if settings.mock_mode else SimulatorClient(settings.simulator_url);self.cache={};self.collector_task=None;self.sse_clients=set();self.started=time.time()
    async def probe_simulator(self):
        """Startup check: real simulator reachable na hole mock e fallback."""
        if self.mode!="simulator":return
        import httpx
        try:
            async with httpx.AsyncClient(timeout=2.5) as c:r=await c.get(settings.simulator_url.rstrip("/")+"/v1/health")
            if r.status_code<500:log.info("Simulator reachable at %s",settings.simulator_url);return
        except Exception as e:log.warning("Simulator not reachable at %s (%s)",settings.simulator_url,e)
        if settings.auto_mock_fallback:
            log.warning("AUTO_MOCK_FALLBACK: switching to built-in MOCK simulator so the UI has data");self.sim=MockSimulatorClient();self.mode="mock-fallback"
    async def refresh(self):
        keys=["instance","regions","depots","stations","routes","supply-arrivals","events","allocations","metrics"]
        for k in keys:
            try:self.cache[k]=await self.sim.get_json("/v1/"+k);self.store.put_snapshot(k,self.cache[k])
            except Exception as e:log.warning("refresh %s failed: %s",k,e)
        try:
            hist=await self.sim.get_json("/v1/demand-history",params={"limit":settings.demand_history_limit});self.store.put_demand(hist);self.cache["demand-history"]=hist
        except Exception as e:log.warning("demand history failed: %s",e)
        SERVICE_LEVEL.set(float(self.cache.get("metrics",{}).get("service_level",0)));SIMULATOR_UP.set(1 if self.sim.last_ok else 0);STALE.set(1 if self.sim.stale else 0)
        await self.broadcast({"type":"refresh","tick":self.cache.get("instance",{}).get("tick")})
    async def collector(self):
        await self.probe_simulator()
        while True:
            if self.mode in("mock","mock-fallback") and getattr(self.sim,"status","")=="RUNNING":self.sim._step()
            try:await self.refresh();self.seed_vehicles()
            except Exception as e:log.exception("collector error: %s",e)
            await asyncio.sleep(settings.poll_seconds)
    async def broadcast(self,event):
        msg=json.dumps(event);dead=[]
        for q in list(self.sse_clients):
            try:q.put_nowait(msg)
            except asyncio.QueueFull:dead.append(q)
        for q in dead:self.sse_clients.discard(q)
    def snapshot(self,key,default=None):
        if key in self.cache:return self.cache[key]
        data,_=self.store.get_snapshot(key);return data if data is not None else default

    # ------------------------------------------------------------------ effective (operator + crisis aware) views
    def tick(self):
        return int((self.cache.get("instance") or {}).get("tick") or 0)
    def tick_minutes(self):
        return int((self.cache.get("instance") or {}).get("tick_minutes") or 15)
    def effects(self):
        return fx.effects(self.ops.crises(),self.tick())
    def seed_vehicles(self):
        """Give every depot 2 default tankers once (operator can edit/delete afterwards)."""
        depots=self.snapshot("depots",[])
        if not depots or self.ops.get_meta("vehicles_seeded"):return
        for d in depots:
            for i in (1,2):
                self.ops.upsert_vehicle({"id":f"veh-{d['id'].replace('depot-','')}-{i}","name":f"{d['name']} Tanker {i}","vehicle_type":"TANKER","capacity_liters":10000,"fuel_types":list(FUELS),"depot_id":d["id"],"status":"AVAILABLE"})
        self.ops.set_meta("vehicles_seeded","1")
    def stations_eff(self):
        e=self.effects();ov=self.ops.status_overrides("station");reg=self.ops.region_overrides();out=[]
        for st in self.snapshot("stations",[]):
            s=dict(st);m=float(s.get("demand_multiplier") or 1.0);s["sim_demand_multiplier"]=m
            m*=float(reg.get(s.get("region_id"),{}).get("multiplier",1.0))*e["region_mult"].get(s.get("region_id"),1.0)*e["station_mult"].get(s["id"],1.0)
            s["demand_multiplier"]=round(m,4);s["sim_status"]=s.get("status");s["status_source"]="simulator"
            if s["id"] in ov:s["status"]=ov[s["id"]]["status"];s["status_source"]="operator"
            if s["id"] in e["closed_stations"]:s["status"]="CLOSED";s["status_source"]="crisis"
            out.append(s)
        return out
    def depots_eff(self):
        e=self.effects();ov=self.ops.status_overrides("depot");out=[]
        for d in self.snapshot("depots",[]):
            x=dict(d);x["sim_status"]=x.get("status");x["status_source"]="simulator"
            if x["id"] in ov:x["status"]=ov[x["id"]]["status"];x["status_source"]="operator"
            if x["id"] in e["closed_depots"]:x["status"]="CLOSED";x["status_source"]="crisis"
            out.append(x)
        return out
    def routes_eff(self):
        e=self.effects();cons=self.ops.route_constraints();out=[]
        for r in self.snapshot("routes",[]):
            x=dict(r);c=cons.get(r["id"]);reasons=[];blocked=r.get("status")!="AVAILABLE"
            if blocked:reasons.append("simulator: "+str(r.get("status")))
            if r["id"] in e["blocked_routes"]:blocked=True;reasons.append("active crisis")
            mx=r.get("max_shipment",0);extra=0
            if c:
                if c["blocked"]:blocked=True;reasons.append(c.get("reason") or "operator block")
                if c.get("max_load_liters") is not None:mx=min(mx,c["max_load_liters"])
                extra=int(c.get("extra_delay_ticks") or 0)
            x.update(sim_status=r.get("status"),sim_max_shipment=r.get("max_shipment"),sim_transit_ticks=r.get("transit_ticks",0),max_shipment=mx,
                     transit_ticks=r.get("transit_ticks",0)+extra,extra_delay_ticks=extra,constraint=c,block_reasons=reasons,blocked=blocked,
                     status="DISRUPTED" if blocked and r.get("status")=="AVAILABLE" else r.get("status"))
            out.append(x)
        return out
    def arrivals_eff(self):
        delays=self.ops.supply_delays("ACTIVE");e=self.effects();out=[]
        for a in self.snapshot("supply-arrivals",[]):
            x=dict(a);total=0;ids=[]
            for d in delays:
                if d["arrival_id"] is not None:match=str(a.get("id"))==str(d["arrival_id"])
                else:match=d["depot_id"] in(None,a.get("depot_id")) and d["fuel_type"] in(None,a.get("fuel_type"))
                if match:total+=d["delay_ticks"];ids.append(d["id"])
            for c in e["delay"]:
                if (not c["depot_ids"] or a.get("depot_id") in c["depot_ids"]) and c["fuel_type"] in(None,a.get("fuel_type")):total+=c["delay_ticks"]
            planned=a.get("planned_tick",0) or 0
            x.update(delayed=total>0,delay_ticks=total,delay_minutes=total*self.tick_minutes(),effective_tick=planned+total,delay_ids=ids)
            out.append(x)
        return out
    def risk_table(self):
        """(risk rows, forecasts) for every station/fuel using operator+crisis-adjusted demand."""
        from .intelligence.forecast import forecast
        from .intelligence.risk import risk_for
        risks=[];fcs={}
        for st in self.stations_eff():
            for fuel in FUELS:
                f=forecast(self.store.demand(st["id"],fuel,200),st,fuel,24);fcs[(st["id"],fuel)]=f;risks.append(risk_for(st,fuel,f))
        return risks,fcs
    def fleet_errors(self,a):
        """Only enforced when the depot has registered vehicles and none can carry this fuel."""
        vs=self.ops.vehicles(depot_id=a["source_depot_id"])
        if not vs:return []
        ok=[v for v in vs if v["status"]=="AVAILABLE" and a["fuel_type"] in v["fuel_types"]]
        return [] if ok else ["NO_VEHICLE_AVAILABLE"]
