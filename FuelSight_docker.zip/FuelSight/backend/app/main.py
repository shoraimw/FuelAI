import time,asyncio,logging
from contextlib import asynccontextmanager
from fastapi import FastAPI,Request
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import make_asgi_app
from .core.config import settings
from .state import AppState
from .observability.logging import setup_logging
from .observability.metrics import REQUESTS,LATENCY
setup_logging(settings.log_level);log=logging.getLogger("fuelsight")
@asynccontextmanager
async def lifespan(app:FastAPI):
    app.state.fs=AppState();app.state.fs.collector_task=asyncio.create_task(app.state.fs.collector());yield
    app.state.fs.collector_task.cancel()
    try:await app.state.fs.collector_task
    except asyncio.CancelledError:pass
app=FastAPI(title="FuelSight API",version="1.0.0",lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=[x.strip() for x in settings.cors_origins.split(",") if x.strip()],allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
@app.middleware("http")
async def metric_mw(request:Request,call_next):
    start=time.perf_counter();response=await call_next(request);path=request.url.path
    REQUESTS.labels(request.method,path,str(response.status_code)).inc();LATENCY.labels(request.method,path).observe(time.perf_counter()-start);return response
from .api import state,intelligence,decisions,simulator_ctl,health,stream,analysis,inventory,regions,transport,supply,crisis
app.include_router(state.router);app.include_router(intelligence.router);app.include_router(decisions.router);app.include_router(simulator_ctl.router);app.include_router(health.router);app.include_router(stream.router);app.include_router(analysis.router)
for _m in (inventory,regions,transport,supply,crisis):app.include_router(_m.router)
app.mount("/metrics",make_asgi_app())
@app.get("/")
async def root():return {"name":"FuelSight","status":"running","docs":"/docs"}
