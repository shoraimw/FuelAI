import json, sqlite3, threading
from pathlib import Path
from datetime import datetime, timezone

class Store:
    def __init__(self, path: str):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True); self.lock=threading.Lock(); self._init()
    def conn(self):
        c=sqlite3.connect(self.path,check_same_thread=False); c.row_factory=sqlite3.Row; return c
    def _init(self):
        with self.conn() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS snapshots(key TEXT PRIMARY KEY,payload TEXT NOT NULL,updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS demand_history(
              station_id TEXT NOT NULL,fuel_type TEXT NOT NULL,tick INTEGER NOT NULL,sim_time TEXT,
              demand_liters REAL,served_liters REAL,unmet_liters REAL,
              PRIMARY KEY(station_id,fuel_type,tick));
            CREATE TABLE IF NOT EXISTS alerts(
              id INTEGER PRIMARY KEY AUTOINCREMENT,alert_key TEXT UNIQUE,severity TEXT,title TEXT,message TEXT,
              station_id TEXT,fuel_type TEXT,status TEXT DEFAULT 'active',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS recommendations(
              id INTEGER PRIMARY KEY AUTOINCREMENT,payload TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS decisions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,recommendation_id INTEGER,action TEXT,operator TEXT,reason TEXT,
              simulator_response TEXT,created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS analyses(
              id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT NOT NULL, created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS audit(
              id INTEGER PRIMARY KEY AUTOINCREMENT,action TEXT,entity_type TEXT,entity_id TEXT,payload TEXT,created_at TEXT NOT NULL);
            """)
    def put_snapshot(self,key,payload):
        now=datetime.now(timezone.utc).isoformat()
        with self.lock,self.conn() as c:
            c.execute("""INSERT INTO snapshots(key,payload,updated_at) VALUES(?,?,?)
            ON CONFLICT(key) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at""",(key,json.dumps(payload),now))
    def get_snapshot(self,key):
        with self.conn() as c:
            r=c.execute("SELECT payload,updated_at FROM snapshots WHERE key=?",(key,)).fetchone()
            return (json.loads(r["payload"]),r["updated_at"]) if r else (None,None)
    def put_demand(self,rows):
        with self.lock,self.conn() as c:
            for x in rows:
                c.execute("""INSERT OR REPLACE INTO demand_history
                (station_id,fuel_type,tick,sim_time,demand_liters,served_liters,unmet_liters)
                VALUES(?,?,?,?,?,?,?)""",(x.get("station_id"),x.get("fuel_type"),x.get("tick"),x.get("sim_time"),
                x.get("demand_liters",0),x.get("served_liters",0),x.get("unmet_liters",0)))
    def demand(self,station_id=None,fuel=None,limit=200):
        q="SELECT * FROM demand_history WHERE 1=1"; args=[]
        if station_id:q+=" AND station_id=?";args.append(station_id)
        if fuel:q+=" AND fuel_type=?";args.append(fuel)
        q+=" ORDER BY tick DESC LIMIT ?";args.append(min(max(limit,1),2000))
        with self.conn() as c:return [dict(r) for r in c.execute(q,args).fetchall()]
    def add_alert(self,key,severity,title,message,station_id=None,fuel=None):
        now=datetime.now(timezone.utc).isoformat()
        with self.lock,self.conn() as c:
            c.execute("""INSERT INTO alerts(alert_key,severity,title,message,station_id,fuel_type,status,created_at,updated_at)
            VALUES(?,?,?,?,?,?, 'active',?,?)
            ON CONFLICT(alert_key) DO UPDATE SET severity=excluded.severity,title=excluded.title,message=excluded.message,
            updated_at=excluded.updated_at,status='active'""",(key,severity,title,message,station_id,fuel,now,now))
    def alerts(self,status=None):
        with self.conn() as c:
            q="SELECT * FROM alerts";args=[]
            if status:q+=" WHERE status=?";args.append(status)
            q+=" ORDER BY id DESC";return [dict(r) for r in c.execute(q,args).fetchall()]
    def ack_alert(self,id):
        with self.conn() as c:c.execute("UPDATE alerts SET status='acknowledged',updated_at=? WHERE id=?",(datetime.now(timezone.utc).isoformat(),id))
    def add_recommendation(self,payload):
        now=datetime.now(timezone.utc).isoformat()
        with self.lock,self.conn() as c:
            r=c.execute("INSERT INTO recommendations(payload,status,created_at,updated_at) VALUES(?,?,?,?)",(json.dumps(payload),"pending",now,now))
            return r.lastrowid
    def recommendations(self,status=None):
        with self.conn() as c:
            q="SELECT * FROM recommendations";args=[]
            if status:q+=" WHERE status=?";args.append(status)
            q+=" ORDER BY id DESC";out=[]
            for r in c.execute(q,args):
                d=json.loads(r["payload"]);d.update(id=r["id"],status=r["status"],created_at=r["created_at"],updated_at=r["updated_at"]);out.append(d)
            return out
    def recommendation(self,id):
        with self.conn() as c:
            r=c.execute("SELECT * FROM recommendations WHERE id=?",(id,)).fetchone()
            if not r:return None
            d=json.loads(r["payload"]);d.update(id=r["id"],status=r["status"],created_at=r["created_at"],updated_at=r["updated_at"]);return d
    def set_recommendation_status(self,id,status):
        with self.conn() as c:c.execute("UPDATE recommendations SET status=?,updated_at=? WHERE id=?",(status,datetime.now(timezone.utc).isoformat(),id))
    def decision(self,rec_id,action,operator="operator",reason="",response=None):
        with self.lock,self.conn() as c:
            c.execute("INSERT INTO decisions(recommendation_id,action,operator,reason,simulator_response,created_at) VALUES(?,?,?,?,?,?)",
                      (rec_id,action,operator,reason,json.dumps(response) if response is not None else None,datetime.now(timezone.utc).isoformat()))
    def decisions(self):
        with self.conn() as c:return [dict(r) for r in c.execute("SELECT * FROM decisions ORDER BY id DESC").fetchall()]
    def audit(self,action,entity_type="",entity_id="",payload=None):
        with self.lock,self.conn() as c:c.execute("INSERT INTO audit(action,entity_type,entity_id,payload,created_at) VALUES(?,?,?,?,?)",
            (action,entity_type,entity_id,json.dumps(payload) if payload is not None else None,datetime.now(timezone.utc).isoformat()))
    def add_analysis(self,payload):
        now=datetime.now(timezone.utc).isoformat()
        with self.lock,self.conn() as c:
            r=c.execute("INSERT INTO analyses(payload,created_at) VALUES(?,?)",(json.dumps(payload),now))
            return r.lastrowid
    def analyses(self,limit=50):
        with self.conn() as c:
            rows=c.execute("SELECT id,payload,created_at FROM analyses ORDER BY id DESC LIMIT ?",(min(max(limit,1),200),)).fetchall()
            out=[]
            for r in rows:
                d=json.loads(r["payload"]); d.update(id=r["id"],created_at=r["created_at"]); out.append(d)
            return out
    def health(self):
        try:
            with self.conn() as c:c.execute("SELECT 1").fetchone()
            return True
        except Exception:return False
