
from .forecast_model import model

def analyze(payload: dict):
    demand_points=payload.get("demand_points",[])
    values=[float(x.get("demand_liters",0)) for x in demand_points if x.get("demand_liters") is not None]
    horizon=max(1,min(int(payload.get("horizon_hours",24)),168))
    current=float(payload.get("current_storage_liters",0))
    capacity=float(payload.get("storage_capacity_liters",max(current,1)))
    incoming=float(payload.get("incoming_supply_liters",0))
    arrival=float(payload.get("incoming_supply_after_hours",0))
    growth=float(payload.get("growth_percent",0))/100
    multiplier=max(0.01,float(payload.get("demand_multiplier",1)))
    preds,confidence,meta=model.predict(values,horizon)
    preds=[round(x*(1+growth)*multiplier,2) for x in preds]
    avg=sum(preds)/max(len(preds),1)
    cumulative=[];stock=current
    stockout=None
    for i,d in enumerate(preds,1):
        if arrival and i>=arrival: stock+=incoming
        stock-=d
        cumulative.append(round(max(0,stock),2))
        if stock<=0 and stockout is None: stockout=i
    safety=max(float(payload.get("safety_stock_percent",25))/100*capacity,0)
    below_safety=next((i for i,s in enumerate(cumulative,1) if s<safety),None)
    total=sum(preds)
    projected_end=cumulative[-1] if cumulative else current
    risk="CRITICAL" if stockout and stockout<=6 else "HIGH" if (stockout and stockout<=12) or (below_safety and below_safety<=12) else "MEDIUM" if (stockout and stockout<=24) or (below_safety and below_safety<=24) else "LOW"
    required=max(0,total+ safety-current-incoming)
    return {
        "region":payload.get("region","Dhaka"),"active":bool(payload.get("active",True)),
        "location_type":payload.get("location_type","station"),"location":payload.get("location","Manual Site"),
        "fuel_type":payload.get("fuel_type","DIESEL"),"horizon_hours":horizon,
        "current_storage_liters":current,"storage_capacity_liters":capacity,
        "incoming_supply_liters":incoming,"incoming_supply_after_hours":arrival,
        "demand_forecast_liters":preds,"total_forecast_liters":round(total,2),
        "average_demand_per_hour":round(avg,2),"projected_storage_liters":cumulative,
        "projected_end_storage_liters":round(projected_end,2),"stockout_hours":stockout,
        "safety_stock_liters":round(safety,2),"safety_threshold_hours":below_safety,
        "risk":risk,"recommended_refill_liters":round(required,2),
        "confidence":round(confidence,3),"model":"FuelSight Ensemble Demand Model",
        "model_details":meta,
        "explanation":[
            f"Forecast uses {meta['samples']} supplied demand observations.",
            f"Demand is adjusted by a {round(multiplier,2)}× multiplier and {round(growth*100,1)}% growth assumption.",
            f"Current storage is {current:,.0f} L against {capacity:,.0f} L capacity.",
            f"Safety stock is {safety:,.0f} L ({payload.get('safety_stock_percent',25)}%).",
            f"Projected risk is {risk}; estimated refill need is {required:,.0f} L."
        ],
        "chart":[{"hour":i+1,"demand":preds[i],"storage":cumulative[i],"safety_stock":round(safety,2)} for i in range(horizon)]
    }
