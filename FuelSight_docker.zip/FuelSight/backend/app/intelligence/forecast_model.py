
from math import sqrt

class DemandForecastModel:
    """Small dependency-free ensemble model for hackathon explainability.
    Combines exponential smoothing, linear trend and recent-window average.
    """

    def __init__(self, alpha=0.35, trend_weight=0.25):
        self.alpha=alpha
        self.trend_weight=trend_weight

    @staticmethod
    def _mean(xs):
        return sum(xs)/len(xs) if xs else 0.0

    @staticmethod
    def _trend(xs):
        if len(xs)<2:
            return 0.0
        n=len(xs)
        xm=(n-1)/2
        ym=sum(xs)/n
        den=sum((i-xm)**2 for i in range(n)) or 1
        return sum((i-xm)*(y-ym) for i,y in enumerate(xs))/den

    def predict(self, values, horizon):
        values=[max(0.0,float(v)) for v in values if v is not None]
        if not values:
            return [0.0]*horizon, 0.35, {"method":"cold-start","samples":0,"trend":0.0}
        level=values[0]
        for v in values[1:]:
            level=self.alpha*v+(1-self.alpha)*level
        recent=self._mean(values[-min(8,len(values)):])
        slope=self._trend(values[-min(12,len(values)):])
        baseline=0.65*level+0.35*recent
        preds=[]
        for step in range(1,horizon+1):
            preds.append(max(0.0, baseline + self.trend_weight*slope*step))
        spread=(sum((v-recent)**2 for v in values[-min(12,len(values)):])/max(1,min(12,len(values))-1))**0.5
        cv=spread/max(recent,1)
        confidence=max(0.45,min(0.97,0.94-0.45*cv+0.015*min(len(values),20)))
        return preds, confidence, {"method":"EMA + recent-window + linear trend","samples":len(values),"trend_per_step":round(slope,3)}

model=DemandForecastModel()
