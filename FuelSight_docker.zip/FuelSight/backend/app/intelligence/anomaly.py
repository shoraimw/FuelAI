from statistics import mean,pstdev
def detect(history,forecast_values=None):
    """history = newest first, demand per tick. Compare newest tick with the previous window (same unit)."""
    vals=[float(x.get("demand_liters",0)) for x in history]
    if len(vals)<8:return {"anomaly":False,"z_score":0.0,"message":"Need more history"}
    actual=vals[0];base=vals[1:25];mu=mean(base);sd=max(pstdev(base),0.15*mu,1.0);z=(actual-mu)/sd
    return {"anomaly":abs(z)>3,"z_score":round(z,2),"message":"Demand spike suspected" if z>3 else "Demand drop suspected" if z<-3 else "No significant anomaly"}
