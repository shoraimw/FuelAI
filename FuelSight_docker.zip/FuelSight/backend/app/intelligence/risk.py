def risk_for(station,fuel,forecast):
    inv=float(station.get("inventory",{}).get(fuel,0));hourly=max(sum(forecast.get("hourly_liters",[])[:4])/4,.1);hours=inv/hourly
    level="CRITICAL" if hours<6 else "HIGH" if hours<12 else "MEDIUM" if hours<24 else "LOW"
    return {"station_id":station["id"],"station_name":station.get("name"),"fuel_type":fuel,"inventory_liters":round(inv,2),
            "forecast_demand_per_hour":round(hourly,2),"hours_to_stockout":round(hours,2),"risk":level,"confidence":forecast.get("confidence",0)}
