from statistics import mean
PROFILES={"urban_high":{"DIESEL":8500,"PETROL":10500,"OCTANE":5600},"industrial":{"DIESEL":14000,"PETROL":4500,"OCTANE":2200},"highway":{"DIESEL":10500,"PETROL":11000,"OCTANE":6200},"regional":{"DIESEL":7200,"PETROL":7600,"OCTANE":3600}}
def hod_factor(profile,hour):
    if profile=="industrial":return 1.55 if 6<=hour<18 else .45
    if profile=="highway":return 1.35 if (6<=hour<10 or 16<=hour<21) else .75
    if profile=="urban_high":return 1.45 if (7<=hour<10 or 16<=hour<21) else .70
    return 1.25 if 7<=hour<21 else .65
def forecast(history,station,fuel,horizon=24):
    base=PROFILES.get(station.get("demand_profile","urban_high"),{}).get(fuel,5000)/24
    multiplier=station.get("demand_multiplier",1.0)
    recent=[float(x.get("demand_liters",0)) for x in history if x.get("fuel_type")==fuel][:48]
    observed=mean(recent)*4 if recent else base
    alpha=.35;level=base
    for x in reversed(recent):level=alpha*x*4+(1-alpha)*level
    conf=min(.95,.55+.01*len(recent));out=[]
    start_hour=0
    try:
        from datetime import datetime
        t=next((x.get("sim_time") for x in history if x.get("sim_time")),None)
        if t:start_hour=(datetime.fromisoformat(str(t).replace("Z","+00:00")).hour+1)%24
    except Exception:start_hour=0
    for h in range(horizon):
        expected=max(.1,.6*level+.4*observed)*hod_factor(station.get("demand_profile","urban_high"),(start_hour+h)%24)*multiplier
        out.append(round(expected,2))
    return {"station_id":station["id"],"fuel_type":fuel,"horizon_hours":horizon,"hourly_liters":out,
            "daily_estimate_liters":round(sum(out),2),"confidence":round(conf,3),"model":"HOD baseline + exponential smoothing"}
