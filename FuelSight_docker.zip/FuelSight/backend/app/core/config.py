from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]  # repo root (folder that contains backend/ and frontend/)

class Settings(BaseSettings):
    app_name: str = "FuelSight"
    app_env: str = "development"
    backend_host: str = "127.0.0.1"
    backend_port: int = 8001
    simulator_url: str = "http://127.0.0.1:8000"
    db_path: str = "./data/fuelsight.db"
    poll_seconds: int = 5
    demand_history_limit: int = 200
    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173"
    mock_mode: bool = False
    auto_mock_fallback: bool = True   # simulator na thakle automatic mock e chole jabe
    log_level: str = "INFO"
    # .env always read from repo root, no matter which folder you start uvicorn from
    model_config = SettingsConfigDict(env_file=str(ROOT / ".env"), extra="ignore")

    @property
    def db_file(self) -> str:
        p = Path(self.db_path)
        return str(p if p.is_absolute() else ROOT / p)

settings = Settings()
