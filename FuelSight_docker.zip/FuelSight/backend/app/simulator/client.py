import asyncio,time,httpx

class CircuitBreaker:
    def __init__(self,threshold=3,reset_seconds=10):
        self.threshold=threshold;self.reset_seconds=reset_seconds;self.failures=0;self.opened_at=0.0
    @property
    def state(self):
        if self.failures<self.threshold:return "CLOSED"
        if time.monotonic()-self.opened_at>=self.reset_seconds:return "HALF_OPEN"
        return "OPEN"
    def before(self):
        if self.state=="OPEN":raise RuntimeError("SIMULATOR_CIRCUIT_OPEN")
    def success(self):self.failures=0;self.opened_at=0.0
    def failure(self):
        self.failures+=1
        if self.failures>=self.threshold:self.opened_at=time.monotonic()

class SimulatorClient:
    def __init__(self,base_url,timeout=4.0):
        self.base=base_url.rstrip("/");self.timeout=timeout;self.cb=CircuitBreaker();self.stale=False;self.last_error=None;self.last_ok=None
    async def request(self,method,path,json_body=None,params=None,retries=3):
        self.cb.before();delay=.4
        for attempt in range(retries):
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as c:r=await c.request(method,self.base+path,json=json_body,params=params)
                self.stale=r.headers.get("X-Simulator-Stale","").lower()=="true"
                if r.status_code in (502,503,504):raise httpx.HTTPStatusError("transient",request=r.request,response=r)
                self.cb.success();self.last_ok=time.time();self.last_error=None;return r
            except (httpx.RequestError,httpx.HTTPStatusError) as e:
                self.last_error=str(e);self.cb.failure()
                if attempt==retries-1:raise
                await asyncio.sleep(delay);delay*=2
        raise RuntimeError("unreachable")
    async def get_json(self,path,params=None):return (await self.request("GET",path,params=params)).json()
    async def post_json(self,path,payload):
        r=await self.request("POST",path,json_body=payload,retries=3);return r.status_code,r.json()
    async def sse(self):
        self.cb.before()
        async with httpx.AsyncClient(timeout=None) as c:
            async with c.stream("GET",self.base+"/v1/stream") as r:
                r.raise_for_status()
                async for line in r.aiter_lines():yield line
