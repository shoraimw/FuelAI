import time,datetime,copy
from .client import CircuitBreaker
class MockSimulatorClient:
    def __init__(self):
        self.cb=CircuitBreaker();self.stale=False;self.last_ok=time.time();self.tick=0;self.status="PAUSED"
        self.regions=[{"id":"region-dhaka","name":"Dhaka Division","demand_factor":1.0},{"id":"region-chattogram","name":"Chattogram Division","demand_factor":1.08}]
        self.depots=[
          {"id":"depot-gazipur","name":"Gazipur Depot","region_id":"region-dhaka","status":"OPEN","dispatch_capacity_per_tick":12000,"capacity":{"DIESEL":90000,"PETROL":70000,"OCTANE":45000},"inventory":{"DIESEL":60000,"PETROL":45000,"OCTANE":26000}},
          {"id":"depot-patiya","name":"Patiya Depot","region_id":"region-chattogram","status":"OPEN","dispatch_capacity_per_tick":11000,"capacity":{"DIESEL":85000,"PETROL":65000,"OCTANE":40000},"inventory":{"DIESEL":55000,"PETROL":42000,"OCTANE":24000}}]
        self.stations=[
          {"id":"station-mirpur","name":"Mirpur Fuel Station","region_id":"region-dhaka","status":"OPEN","demand_profile":"urban_high","demand_multiplier":1.0,"capacity":{"DIESEL":15000,"PETROL":14000,"OCTANE":9000},"inventory":{"DIESEL":9000,"PETROL":9000,"OCTANE":5000}},
          {"id":"station-tongi","name":"Tongi Fuel Station","region_id":"region-dhaka","status":"OPEN","demand_profile":"industrial","demand_multiplier":1.0,"capacity":{"DIESEL":18000,"PETROL":9000,"OCTANE":6000},"inventory":{"DIESEL":11000,"PETROL":6000,"OCTANE":3500}},
          {"id":"station-karnaphuli","name":"Karnaphuli Fuel Station","region_id":"region-chattogram","status":"OPEN","demand_profile":"highway","demand_multiplier":1.0,"capacity":{"DIESEL":14000,"PETROL":15000,"OCTANE":9000},"inventory":{"DIESEL":8500,"PETROL":9500,"OCTANE":5200}},
          {"id":"station-coxsbazar","name":"Coxsbazar Fuel Station","region_id":"region-chattogram","status":"OPEN","demand_profile":"regional","demand_multiplier":1.0,"capacity":{"DIESEL":12000,"PETROL":12000,"OCTANE":7000},"inventory":{"DIESEL":7500,"PETROL":7500,"OCTANE":4200}}]
        self.routes=[
          {"id":"route-gazipur-mirpur","source_depot_id":"depot-gazipur","destination_station_id":"station-mirpur","transit_ticks":2,"max_shipment":7000,"status":"AVAILABLE"},
          {"id":"route-gazipur-tongi","source_depot_id":"depot-gazipur","destination_station_id":"station-tongi","transit_ticks":2,"max_shipment":6500,"status":"AVAILABLE"},
          {"id":"route-patiya-karnaphuli","source_depot_id":"depot-patiya","destination_station_id":"station-karnaphuli","transit_ticks":2,"max_shipment":7000,"status":"AVAILABLE"},
          {"id":"route-patiya-coxsbazar","source_depot_id":"depot-patiya","destination_station_id":"station-coxsbazar","transit_ticks":3,"max_shipment":6000,"status":"AVAILABLE"},
          {"id":"route-gazipur-karnaphuli","source_depot_id":"depot-gazipur","destination_station_id":"station-karnaphuli","transit_ticks":4,"max_shipment":5000,"status":"AVAILABLE"},
          {"id":"route-patiya-mirpur","source_depot_id":"depot-patiya","destination_station_id":"station-mirpur","transit_ticks":4,"max_shipment":5000,"status":"AVAILABLE"}]
        self.allocations=[];self.events=[];self.supplies=[];self.demand=[]
        for _ in range(32):self._step()  # seed ~8h history so forecasts/risk have data immediately
        self.status="RUNNING"
    def _instance(self):
        t=datetime.datetime(2026,1,1,tzinfo=datetime.timezone.utc)+datetime.timedelta(minutes=15*self.tick)
        return {"id":1,"scenario_id":"mock","scenario_version":"1.0","seed":12345,"sim_time":t.isoformat(),"tick":self.tick,"tick_minutes":15,"status":self.status}
    async def get_json(self,path,params=None):
        self.last_ok=time.time()
        if path=="/v1/health":return {"status":"ok","database":"ok","simulation":{"status":self.status,"tick":self.tick}}
        if path=="/v1/instance":return self._instance()
        if path=="/v1/regions":return copy.deepcopy(self.regions)
        if path=="/v1/depots":return copy.deepcopy(self.depots)
        if path=="/v1/stations":return copy.deepcopy(self.stations)
        if path=="/v1/routes":return copy.deepcopy(self.routes)
        if path=="/v1/supply-arrivals":return copy.deepcopy(self.supplies)
        if path=="/v1/events":return copy.deepcopy(self.events)
        if path=="/v1/allocations":return copy.deepcopy(self.allocations)
        if path=="/v1/demand-history":
            limit=int((params or {}).get("limit",200));return copy.deepcopy(self.demand[-limit:])
        if path=="/v1/metrics":return {"served_demand_liters":0,"unmet_demand_liters":0,"service_level":1.0,"allocation_liters":sum(x["quantity"] for x in self.allocations),"allocation_failures":0}
        raise KeyError(path)
    def _step(self):
        self.tick+=1
        for a in self.allocations:
            if a["status"]=="IN_TRANSIT" and a["expected_arrival_tick"]<=self.tick:
                st=next((x for x in self.stations if x["id"]==a["destination_station_id"]),None)
                if st:st["inventory"][a["fuel_type"]]=min(st["capacity"][a["fuel_type"]],st["inventory"][a["fuel_type"]]+a["quantity"])
                a["status"]="DELIVERED";a["actual_arrival_tick"]=self.tick
        for st in self.stations:
            for fuel in ("DIESEL","PETROL","OCTANE"):
                day={"urban_high":{"DIESEL":8500,"PETROL":10500,"OCTANE":5600},"industrial":{"DIESEL":14000,"PETROL":4500,"OCTANE":2200},"highway":{"DIESEL":10500,"PETROL":11000,"OCTANE":6200},"regional":{"DIESEL":7200,"PETROL":7600,"OCTANE":3600}}[st["demand_profile"]][fuel]
                demand=day/96*st["demand_multiplier"]
                served=min(st["inventory"][fuel],demand);st["inventory"][fuel]-=served
                self.demand.append({"station_id":st["id"],"fuel_type":fuel,"tick":self.tick,"sim_time":self._instance()["sim_time"],"demand_liters":demand,"served_liters":served,"unmet_liters":demand-served})
    async def post_json(self,path,payload):
        self.last_ok=time.time()
        if path=="/admin/run":self.status="RUNNING";return 200,{"status":"RUNNING"}
        if path=="/admin/pause":self.status="PAUSED";return 200,{"status":"PAUSED"}
        if path=="/admin/toggle":self.status="PAUSED" if self.status=="RUNNING" else "RUNNING";return 200,{"status":self.status}
        if path=="/admin/step":self._step();return 200,{"tick":self.tick,"sim_time":self._instance()["sim_time"]}
        if path=="/admin/reset":self.__init__();return 200,{"status":"reset"}
        if path=="/admin/events":
            p=payload.copy();p["id"]=len(self.events)+1;p["status"]="SCHEDULED";p["end_tick"]=p["start_tick"]+p["duration_ticks"];self.events.insert(0,p)
            if p["type"]=="demand_spike":
                for st in self.stations:
                    if st["region_id"] in p.get("parameters",{}).get("region_ids",[]):st["demand_multiplier"]=p.get("parameters",{}).get("multiplier",1.5)
            if p["type"]=="route_disruption":
                for r in self.routes:
                    if r["id"] in p.get("parameters",{}).get("route_ids",[]):r["status"]="DISRUPTED"
            return 201,p
        if path=="/admin/faults":return 201,{"type":payload.get("type"),"status":"ACTIVE"}
        if path=="/admin/faults/clear":self.stale=False;return 200,{"status":"cleared"}
        if path=="/v1/allocations":
            key=payload["idempotency_key"]
            for a in self.allocations:
                if a["idempotency_key"]==key:return 201,a
            r=next(x for x in self.routes if x["id"]==payload["route_id"]);d=next(x for x in self.depots if x["id"]==payload["source_depot_id"]);s=next(x for x in self.stations if x["id"]==payload["destination_station_id"]);f=payload["fuel_type"]
            if r["status"]!="AVAILABLE":return 409,{"detail":{"code":"ROUTE_DISRUPTED","message":"Route unavailable"}}
            if d["inventory"][f]<payload["quantity"]:return 409,{"detail":{"code":"INSUFFICIENT_INVENTORY","message":"Insufficient inventory"}}
            if s["inventory"][f]+payload["quantity"]>s["capacity"][f]:return 409,{"detail":{"code":"DESTINATION_CAPACITY_EXCEEDED","message":"Destination capacity exceeded"}}
            d["inventory"][f]-=payload["quantity"];a={**payload,"id":len(self.allocations)+1,"created_tick":self.tick,"departure_tick":self.tick+1,"expected_arrival_tick":self.tick+r["transit_ticks"],"actual_arrival_tick":None,"status":"IN_TRANSIT","failure_reason":None};self.allocations.insert(0,a);return 201,a
        return 200,{"ok":True}
    async def sse(self):
        while True:
            yield ": keepalive";import asyncio;await asyncio.sleep(15)
