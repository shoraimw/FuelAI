from .constraints import validate_candidate
def generate_recommendations(stations,depots,routes,risks,forecasts):
    out=[];rank={"CRITICAL":0,"HIGH":1,"MEDIUM":2,"LOW":3}
    for risk in sorted(risks,key=lambda x:(rank[x["risk"]],x["hours_to_stockout"])):
        if risk["risk"]=="LOW":continue
        st=next(s for s in stations if s["id"]==risk["station_id"]);fuel=risk["fuel_type"];best=None
        for r in routes:
            if r["destination_station_id"]!=st["id"] or r["status"]!="AVAILABLE":continue
            d=next((d for d in depots if d["id"]==r["source_depot_id"]),None)
            if not d:continue
            hourly=risk["forecast_demand_per_hour"];target=max(1000,st["inventory"][fuel]*0.8)
            qty=min(r["max_shipment"],d["inventory"].get(fuel,0),d["dispatch_capacity_per_tick"],st["capacity"][fuel]-st["inventory"][fuel],target)
            if qty<=0:continue
            c={"source_depot_id":d["id"],"destination_station_id":st["id"],"route_id":r["id"],"fuel_type":fuel,"quantity":round(qty,2)}
            errs=validate_candidate(c,depots,stations,routes)
            if errs:continue
            after=max(0,st["inventory"][fuel]+qty-(r["transit_ticks"]*.25)*hourly);after_hours=after/max(hourly,.1)
            reduction=max(0,min(100,100*(1-risk["hours_to_stockout"]/max(after_hours,.1))))
            score=(risk["hours_to_stockout"]<12,-r["transit_ticks"],qty)
            if best is None or score>best[0]:best=(score,c,d,r,after_hours,reduction)
        if best:
            _,c,d,r,after_hours,reduction=best
            out.append({"title":f"Refill {st['name']} {fuel}","allocation":c,"risk_before":risk,
              "projected_hours_after":round(after_hours,2),"risk_reduction_percent":round(reduction,1),"confidence":risk["confidence"],
              "why":[f"{risk['risk']} stockout risk",f"{risk['hours_to_stockout']}h projected cover",f"{d['name']} has available {fuel} inventory",f"Transit {r['transit_ticks']} ticks"],
              "constraints":{"precheck":"PASS","checks":["route available","inventory sufficient","route max shipment","destination capacity","depot dispatch capacity"]},"alternatives":[]})
    return out
