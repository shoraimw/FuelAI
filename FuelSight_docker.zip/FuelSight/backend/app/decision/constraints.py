def validate_candidate(c,depots,stations,routes):
    errs=[];d=next((x for x in depots if x["id"]==c["source_depot_id"]),None);s=next((x for x in stations if x["id"]==c["destination_station_id"]),None);r=next((x for x in routes if x["id"]==c["route_id"]),None)
    if not d or not s or not r:return ["NOT_FOUND"]
    if (r["source_depot_id"],r["destination_station_id"])!=(d["id"],s["id"]):errs.append("ROUTE_MISMATCH")
    if d.get("status") not in ("OPEN","CONSTRAINED"):errs.append("DEPOT_CLOSED")
    if s.get("status")!="OPEN":errs.append("STATION_CLOSED")
    if r.get("status")!="AVAILABLE":errs.append("ROUTE_DISRUPTED")
    if c["quantity"]>r.get("max_shipment",0):errs.append("ROUTE_CAPACITY_EXCEEDED")
    fuel=c["fuel_type"]
    if d.get("inventory",{}).get(fuel,0)<c["quantity"]:errs.append("INSUFFICIENT_INVENTORY")
    if s.get("inventory",{}).get(fuel,0)+c["quantity"]>s.get("capacity",{}).get(fuel,0):errs.append("DESTINATION_CAPACITY_EXCEEDED")
    return errs
