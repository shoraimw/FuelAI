import asyncio
from fastapi import APIRouter,Request
from fastapi.responses import StreamingResponse
router=APIRouter(prefix="/api",tags=["stream"])
@router.get("/stream")
async def stream(request:Request):
    q=asyncio.Queue(maxsize=200);request.app.state.fs.sse_clients.add(q)
    async def gen():
        try:
            yield "event: connected\ndata: {}\n\n"
            while not await request.is_disconnected():
                try:yield f"event: update\ndata: {await asyncio.wait_for(q.get(),timeout=15)}\n\n"
                except asyncio.TimeoutError:yield ": keepalive\n\n"
        finally:request.app.state.fs.sse_clients.discard(q)
    return StreamingResponse(gen(),media_type="text/event-stream",headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})
