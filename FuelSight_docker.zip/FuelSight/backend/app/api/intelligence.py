from fastapi import APIRouter,Request
from ..intelligence.forecast import forecast
from ..intelligence.risk import risk_for
from ..intelligence.anomaly import detect
from ..observability.metrics import PREDICTION_CONF
router=APIRouter(prefix="/api",tags=["intelligence"])
@router.get("/forecast/{station_id}/{fuel}")
async def get_forecast(station_id:str,fuel:str,request:Request,horizon:int=24):
    s=request.app.state.fs;st=next((x for x in s.stations_eff() if x["id"]==station_id),None)
    if not st:return {"error":"station_not_found"}
    f=forecast(s.store.demand(station_id,fuel,200),st,fuel,horizon);PREDICTION_CONF.set(f["confidence"]);return f
@router.get("/risk")
async def risk(request:Request):
    s=request.app.state.fs;out=[]
    for st in s.stations_eff():
        for fuel in ("DIESEL","PETROL","OCTANE"):
            hist=s.store.demand(st["id"],fuel,200);f=forecast(hist,st,fuel,24);out.append(risk_for(st,fuel,f))
            a=detect(hist,f["hourly_liters"])
            if a["anomaly"]:s.store.add_alert(f"anomaly:{st['id']}:{fuel}","HIGH","Demand anomaly",f"{a['message']} (z={a['z_score']})",st["id"],fuel)
    return out
@router.get("/alerts")
async def alerts(request:Request,status:str|None=None):return request.app.state.fs.store.alerts(status)
@router.post("/alerts/{id}/ack")
async def ack(id:int,request:Request):request.app.state.fs.store.ack_alert(id);return {"status":"acknowledged"}
