import math, uuid
from typing import List, Literal, Optional
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel, Field
from ..decision.constraints import validate_candidate
from ..state import FUELS

router = APIRouter(prefix="/api/transport", tags=["transport & routes"])
Fuel = Literal["DIESEL", "PETROL", "OCTANE"]

class VehicleIn(BaseModel):
    id: Optional[str] = None
    name: str
    vehicle_type: str = "TANKER"
    capacity_liters: float = Field(gt=0)
    fuel_types: List[Fuel] = list(FUELS)
    depot_id: Optional[str] = None
    status: Literal["AVAILABLE", "IN_TRANSIT", "MAINTENANCE", "OFFLINE"] = "AVAILABLE"
    driver: Optional[str] = None
    notes: Optional[str] = None

class VehicleStatus(BaseModel):
    status: Literal["AVAILABLE", "IN_TRANSIT", "MAINTENANCE", "OFFLINE"]

class RouteConstraint(BaseModel):
    blocked: bool = False
    max_load_liters: Optional[float] = Field(default=None, gt=0)
    extra_delay_ticks: int = Field(default=0, ge=0, le=500)
    reason: Optional[str] = None

class PlanIn(BaseModel):
    route_id: str
    fuel_type: Fuel
    quantity: float = Field(gt=0)
    vehicle_id: Optional[str] = None

def _check_depot(s, depot_id):
    if depot_id and not any(d["id"] == depot_id for d in s.snapshot("depots", [])):
        raise HTTPException(422, f"Unknown depot_id '{depot_id}'")

# ---------------- vehicles
@router.get("/vehicles")
async def vehicles(request: Request, depot_id: Optional[str] = None, status: Optional[str] = None):
    s = request.app.state.fs; s.seed_vehicles()
    return s.ops.vehicles(depot_id, status)

@router.post("/vehicles", status_code=201)
async def create_vehicle(body: VehicleIn, request: Request):
    s = request.app.state.fs; _check_depot(s, body.depot_id); v = body.model_dump(); v["id"] = v["id"] or "veh-" + uuid.uuid4().hex[:8]
    if s.ops.vehicle(v["id"]): raise HTTPException(409, "Vehicle id already exists")
    out = s.ops.upsert_vehicle(v); s.store.audit("vehicle_create", "vehicle", v["id"], v); return out

@router.get("/vehicles/{id}")
async def get_vehicle(id: str, request: Request):
    v = request.app.state.fs.ops.vehicle(id)
    if not v: raise HTTPException(404, "Vehicle not found")
    return v

@router.put("/vehicles/{id}")
async def update_vehicle(id: str, body: VehicleIn, request: Request):
    s = request.app.state.fs
    if not s.ops.vehicle(id): raise HTTPException(404, "Vehicle not found")
    _check_depot(s, body.depot_id); v = body.model_dump(); v["id"] = id
    out = s.ops.upsert_vehicle(v); s.store.audit("vehicle_update", "vehicle", id, v); return out

@router.post("/vehicles/{id}/status")
async def vehicle_status(id: str, body: VehicleStatus, request: Request):
    s = request.app.state.fs; v = s.ops.vehicle(id)
    if not v: raise HTTPException(404, "Vehicle not found")
    v["status"] = body.status; return s.ops.upsert_vehicle(v)

@router.delete("/vehicles/{id}")
async def delete_vehicle(id: str, request: Request):
    if not request.app.state.fs.ops.delete_vehicle(id): raise HTTPException(404, "Vehicle not found")
    return {"status": "deleted", "id": id}

# ---------------- routes + travel constraints
def _route_view(s, r):
    depots = {d["id"]: d for d in s.snapshot("depots", [])}; stations = {x["id"]: x for x in s.snapshot("stations", [])}; tm = s.tick_minutes()
    vs = s.ops.vehicles(depot_id=r["source_depot_id"])
    return {**r, "source_depot_name": depots.get(r["source_depot_id"], {}).get("name"), "destination_station_name": stations.get(r["destination_station_id"], {}).get("name"),
            "travel_minutes": r["transit_ticks"] * tm, "sim_travel_minutes": r["sim_transit_ticks"] * tm, "tick_minutes": tm,
            "vehicles_available": sum(1 for v in vs if v["status"] == "AVAILABLE")}

@router.get("/routes")
async def routes(request: Request, blocked: Optional[bool] = None, depot_id: Optional[str] = None, station_id: Optional[str] = None):
    s = request.app.state.fs
    return [_route_view(s, r) for r in s.routes_eff() if (blocked is None or r["blocked"] == blocked) and (not depot_id or r["source_depot_id"] == depot_id)
            and (not station_id or r["destination_station_id"] == station_id)]

def _route(s, id):
    r = next((x for x in s.routes_eff() if x["id"] == id), None)
    if not r: raise HTTPException(404, "Route not found")
    return r

@router.get("/routes/{id}")
async def route(id: str, request: Request):
    s = request.app.state.fs; return _route_view(s, _route(s, id))

@router.put("/routes/{id}/constraints")
async def set_constraints(id: str, body: RouteConstraint, request: Request):
    """Travel constraints: block the route, cap the load per shipment, or add delay ticks (traffic, weather, checkpoint...)."""
    s = request.app.state.fs; _route(s, id)
    s.ops.set_route_constraint(id, body.blocked, body.max_load_liters, body.extra_delay_ticks, body.reason); s.store.audit("route_constraint", "route", id, body.model_dump())
    await s.broadcast({"type": "route_constraint", "route_id": id}); return _route_view(s, _route(s, id))

@router.delete("/routes/{id}/constraints")
async def clear_constraints(id: str, request: Request):
    s = request.app.state.fs; _route(s, id); s.ops.clear_route_constraint(id); return _route_view(s, _route(s, id))

# ---------------- shipment planner (dry run, nothing is sent to the simulator)
@router.post("/plan")
async def plan(body: PlanIn, request: Request):
    s = request.app.state.fs; r = _route(s, body.route_id); depots = s.depots_eff(); stations = s.stations_eff()
    a = {"source_depot_id": r["source_depot_id"], "destination_station_id": r["destination_station_id"], "route_id": r["id"], "fuel_type": body.fuel_type, "quantity": body.quantity}
    errors = validate_candidate(a, depots, stations, s.routes_eff()) + s.fleet_errors(a); warnings = []
    fleet = [v for v in s.ops.vehicles(depot_id=r["source_depot_id"]) if v["status"] == "AVAILABLE" and body.fuel_type in v["fuel_types"]]
    if body.vehicle_id:
        v = s.ops.vehicle(body.vehicle_id)
        if not v: raise HTTPException(404, "Vehicle not found")
        if v["depot_id"] != r["source_depot_id"]: errors.append("VEHICLE_WRONG_DEPOT")
        if v["status"] != "AVAILABLE": errors.append("VEHICLE_NOT_AVAILABLE")
        if body.fuel_type not in v["fuel_types"]: errors.append("VEHICLE_FUEL_MISMATCH")
        fleet = [v]
    cap = max((v["capacity_liters"] for v in fleet), default=0); trips = math.ceil(body.quantity / cap) if cap else None
    if trips and trips > len(fleet): warnings.append(f"Needs {trips} trips but only {len(fleet)} vehicle(s) available - shipment will be sequential")
    if r["extra_delay_ticks"]: warnings.append(f"Route has +{r['extra_delay_ticks']} tick operator delay")
    st = next(x for x in stations if x["id"] == r["destination_station_id"]); inv = float(st["inventory"].get(body.fuel_type, 0)); capd = float(st["capacity"].get(body.fuel_type, 0)); tick = s.tick()
    return {"feasible": not errors, "errors": sorted(set(errors)), "warnings": warnings, "allocation": a, "route": _route_view(s, r),
            "eta": {"departure_tick": tick + 1, "transit_ticks": r["transit_ticks"], "arrival_tick": tick + r["transit_ticks"], "travel_minutes": r["transit_ticks"] * s.tick_minutes()},
            "fleet": {"available_vehicles": [v["id"] for v in fleet], "max_vehicle_capacity_liters": cap, "trips_required": trips},
            "after_delivery": {"station_inventory_liters": round(inv + body.quantity, 2), "station_fill_percent": round(100 * (inv + body.quantity) / capd, 1) if capd else None}}
