from fastapi import APIRouter,Request
router=APIRouter(prefix="/api",tags=["ops"])
@router.get("/health")
async def health(request:Request):
    s=request.app.state.fs;ok=False
    try:ok=(await s.sim.get_json("/v1/health")).get("status")=="ok"
    except Exception:pass
    return {"backend":"healthy","database":"healthy" if s.store.health() else "unhealthy","simulator":"healthy" if ok else "degraded",
      "prediction_service":"healthy","decision_engine":"healthy","degraded":not ok or s.sim.stale,"circuit_breaker":s.sim.cb.state,"stale":s.sim.stale,"mode":s.mode}
