
from fastapi import APIRouter, Request, HTTPException
from ..intelligence.analysis import analyze

router=APIRouter(prefix="/api/analysis",tags=["analysis"])

@router.post("/manual")
async def manual(payload:dict,request:Request):
    if not payload.get("location"): raise HTTPException(422,"location is required")
    if float(payload.get("storage_capacity_liters",0))<=0: raise HTTPException(422,"storage capacity must be > 0")
    result=analyze(payload)
    result["source"]="MANUAL"
    result["input"]=payload
    result["analysis_id"]=request.app.state.fs.store.add_analysis(result)
    return result

@router.get("/history")
async def history(request:Request,limit:int=50):
    return request.app.state.fs.store.analyses(limit)

@router.get("/model")
async def model_info():
    return {
      "name":"FuelSight Ensemble Demand Model",
      "type":"dependency-free time-series ensemble",
      "components":["exponential smoothing","recent-window average","linear trend"],
      "features":["historical demand","growth assumption","demand multiplier","storage","incoming supply"],
      "purpose":"demand forecasting and storage trajectory prediction",
      "confidence":"data-volume and recent-demand-variance based"
    }
