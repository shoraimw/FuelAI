from typing import Literal, Optional, Union
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/supply", tags=["supply & delays"])

class DelayIn(BaseModel):
    arrival_id: Optional[Union[int, str]] = None
    depot_id: Optional[str] = None
    fuel_type: Optional[Literal["DIESEL", "PETROL", "OCTANE"]] = None
    delay_ticks: int = Field(ge=1, le=1000)
    reason: Optional[str] = None

@router.get("/arrivals")
async def arrivals(request: Request, delayed: Optional[bool] = None, depot_id: Optional[str] = None):
    s = request.app.state.fs; rows = [a for a in s.arrivals_eff() if (delayed is None or a["delayed"] == delayed) and (not depot_id or a.get("depot_id") == depot_id)]
    d = [a for a in rows if a["delayed"]]
    return {"tick": s.tick(), "arrivals": rows, "summary": {"total": len(rows), "delayed": len(d), "delayed_liters": round(sum(float(a.get("quantity", 0)) for a in d), 2),
            "max_delay_ticks": max((a["delay_ticks"] for a in d), default=0)}}

@router.get("/delays")
async def delays(request: Request, status: Optional[str] = None):
    return request.app.state.fs.ops.supply_delays(status)

@router.post("/delays", status_code=201)
async def create_delay(body: DelayIn, request: Request):
    """Record a supply delay for one arrival (arrival_id) or for a depot / depot+fuel. Effective arrival tick is shifted in /arrivals."""
    s = request.app.state.fs; depot_id, fuel = body.depot_id, body.fuel_type; arrival_id = None
    if body.arrival_id is not None:
        a = next((x for x in s.snapshot("supply-arrivals", []) if str(x.get("id")) == str(body.arrival_id)), None)
        if not a: raise HTTPException(404, "Supply arrival not found")
        arrival_id = str(a["id"]); depot_id = a.get("depot_id"); fuel = a.get("fuel_type")
    elif not depot_id: raise HTTPException(422, "Provide arrival_id or depot_id")
    if depot_id and not any(d["id"] == depot_id for d in s.snapshot("depots", [])): raise HTTPException(422, f"Unknown depot_id '{depot_id}'")
    row = s.ops.add_supply_delay(arrival_id, depot_id, fuel, body.delay_ticks, body.reason)
    s.store.add_alert(f"supply-delay:{row['id']}", "HIGH" if body.delay_ticks >= 8 else "MEDIUM", "Supply delay", f"{depot_id or 'network'} {fuel or 'all fuels'} delayed by {body.delay_ticks} ticks. {body.reason or ''}".strip(), None, fuel)
    s.store.audit("supply_delay", "supply_delay", str(row["id"]), row); await s.broadcast({"type": "supply_delay", "id": row["id"]}); return row

@router.post("/delays/{id}/resolve")
async def resolve(id: int, request: Request):
    s = request.app.state.fs
    if not s.ops.supply_delay(id): raise HTTPException(404, "Delay not found")
    return s.ops.resolve_supply_delay(id)

@router.delete("/delays/{id}")
async def delete(id: int, request: Request):
    if not request.app.state.fs.ops.delete_supply_delay(id): raise HTTPException(404, "Delay not found")
    return {"status": "deleted", "id": id}
