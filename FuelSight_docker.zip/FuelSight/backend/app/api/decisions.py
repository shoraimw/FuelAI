import uuid
from fastapi import APIRouter,Request,HTTPException
from ..decision.optimizer import generate_recommendations
router=APIRouter(prefix="/api",tags=["decisions"])
@router.post("/recommendations/generate")
async def generate(request:Request):
    s=request.app.state.fs;stations=s.stations_eff();depots=s.depots_eff();routes=s.routes_eff();risks=[];forecasts={}
    from ..intelligence.forecast import forecast
    from ..intelligence.risk import risk_for
    for st in stations:
        for fuel in ("DIESEL","PETROL","OCTANE"):
            f=forecast(s.store.demand(st["id"],fuel,200),st,fuel,24);forecasts[(st["id"],fuel)]=f;risks.append(risk_for(st,fuel,f))
    recs=generate_recommendations(stations,depots,routes,risks,forecasts)
    for r in recs:
        k="fs-"+uuid.uuid4().hex;r["idempotency_key"]=k;r["allocation"]["idempotency_key"]=k;s.store.add_recommendation(r)
    await s.broadcast({"type":"recommendations","count":len(recs)})
    return {"created":len(recs),"recommendations":s.store.recommendations("pending")}
@router.get("/recommendations")
async def recommendations(request:Request,status:str|None=None):return request.app.state.fs.store.recommendations(status)
@router.get("/recommendations/{id}")
async def recommendation(id:int,request:Request):
    x=request.app.state.fs.store.recommendation(id)
    if not x:raise HTTPException(404,"Recommendation not found")
    return x
@router.post("/recommendations/{id}/reject")
async def reject(id:int,request:Request,body:dict|None=None):
    s=request.app.state.fs;r=s.store.recommendation(id)
    if not r:raise HTTPException(404,"Recommendation not found")
    s.store.set_recommendation_status(id,"rejected");s.store.decision(id,"REJECTED",(body or {}).get("operator","operator"),(body or {}).get("reason",""),None);return {"status":"rejected"}
@router.post("/recommendations/{id}/approve")
async def approve(id:int,request:Request,body:dict|None=None):
    s=request.app.state.fs;r=s.store.recommendation(id)
    if not r:raise HTTPException(404,"Recommendation not found")
    if r["status"]!="pending":raise HTTPException(409,"Recommendation already resolved")
    a=r["allocation"];await s.refresh()
    from ..decision.constraints import validate_candidate
    errs=validate_candidate(a,s.depots_eff(),s.stations_eff(),s.routes_eff())+s.fleet_errors(a)
    if errs:
        s.store.decision(id,"REJECTED",(body or {}).get("operator","operator"),"Pre-check failed: "+",".join(errs),{"errors":errs});raise HTTPException(409,{"code":"PRECHECK_FAILED","errors":errs})
    try:
        status,payload=await s.sim.post_json("/v1/allocations",a)
        if status not in (200,201):
            s.store.decision(id,"FAILED",(body or {}).get("operator","operator"),"Simulator rejected allocation",payload);raise HTTPException(status,payload)
        s.store.set_recommendation_status(id,"approved");s.store.decision(id,"APPROVED",(body or {}).get("operator","operator"),"Human approved recommendation",payload)
        await s.broadcast({"type":"decision","recommendation_id":id,"action":"APPROVED"});return {"status":"approved","simulator_status":status,"allocation":payload}
    except HTTPException:raise
    except Exception as e:
        s.store.decision(id,"FAILED",(body or {}).get("operator","operator"),str(e),None);raise HTTPException(503,{"code":"SIMULATOR_UNAVAILABLE","message":str(e)})
@router.get("/decisions")
async def decisions(request:Request):return request.app.state.fs.store.decisions()
