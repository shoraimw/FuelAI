from typing import List, Literal, Optional
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel, Field
from ..ops import effects as fx

router = APIRouter(prefix="/api/crises", tags=["crisis conditions"])

class CrisisIn(BaseModel):
    type: Literal["DEMAND_SPIKE", "ROUTE_DISRUPTION", "DEPOT_OUTAGE", "STATION_CLOSURE", "SUPPLY_DELAY", "FUEL_SHORTAGE", "OTHER"]
    severity: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"] = "MEDIUM"
    title: str
    region_id: Optional[str] = None
    station_ids: List[str] = []
    route_ids: List[str] = []
    depot_ids: List[str] = []
    fuel_type: Optional[Literal["DIESEL", "PETROL", "OCTANE"]] = None
    demand_multiplier: float = Field(default=1.5, gt=0.1, le=5.0)
    delay_ticks: int = Field(default=0, ge=0, le=1000)
    start_tick: Optional[int] = Field(default=None, ge=0)
    duration_ticks: Optional[int] = Field(default=None, ge=1)
    note: Optional[str] = None
    forward_to_simulator: bool = False

def _validate(s, b: CrisisIn):
    ids = lambda key: {x["id"] for x in s.snapshot(key, [])}
    if b.region_id and b.region_id not in ids("regions"): raise HTTPException(422, f"Unknown region_id '{b.region_id}'")
    for key, vals, label in (("stations", b.station_ids, "station_ids"), ("routes", b.route_ids, "route_ids"), ("depots", b.depot_ids, "depot_ids")):
        bad = [v for v in vals if v not in ids(key)]
        if bad: raise HTTPException(422, f"Unknown {label}: {bad}")
    need = {"DEMAND_SPIKE": bool(b.region_id or b.station_ids), "ROUTE_DISRUPTION": bool(b.route_ids), "DEPOT_OUTAGE": bool(b.depot_ids),
            "STATION_CLOSURE": bool(b.station_ids), "SUPPLY_DELAY": b.delay_ticks > 0}
    msg = {"DEMAND_SPIKE": "region_id or station_ids required", "ROUTE_DISRUPTION": "route_ids required", "DEPOT_OUTAGE": "depot_ids required",
           "STATION_CLOSURE": "station_ids required", "SUPPLY_DELAY": "delay_ticks > 0 required"}
    if not need.get(b.type, True): raise HTTPException(422, f"{b.type}: {msg[b.type]}")

@router.get("")
async def list_crises(request: Request, status: Optional[str] = None):
    """status: ACTIVE | SCHEDULED | EXPIRED | RESOLVED (computed against the simulator tick)"""
    s = request.app.state.fs; rows = fx.with_state(s.ops.crises(), s.tick())
    return [r for r in rows if not status or r["state"] == status.upper()]

@router.get("/level")
async def level(request: Request):
    s = request.app.state.fs; risks, _ = s.risk_table(); rows = fx.with_state(s.ops.crises(), s.tick())
    out = fx.crisis_level(s.ops.crises(), s.tick(), risks); out["tick"] = s.tick()
    out["active"] = [r for r in rows if r["state"] == "ACTIVE"]; out["top_risks"] = sorted([r for r in risks if r["risk"] in ("CRITICAL", "HIGH")], key=lambda r: r["hours_to_stockout"])[:8]
    return out

@router.post("", status_code=201)
async def create(body: CrisisIn, request: Request):
    s = request.app.state.fs; _validate(s, body); d = body.model_dump(); forward = d.pop("forward_to_simulator")
    d["start_tick"] = body.start_tick if body.start_tick is not None else s.tick(); d["forwarded"] = False; forward_error = None
    if forward and body.type in ("DEMAND_SPIKE", "ROUTE_DISRUPTION"):
        try:
            if body.type == "DEMAND_SPIKE":
                regions = [body.region_id] if body.region_id else sorted({x["region_id"] for x in s.snapshot("stations", []) if x["id"] in body.station_ids})
                payload = {"type": "demand_spike", "start_tick": d["start_tick"], "duration_ticks": body.duration_ticks or 96, "parameters": {"region_ids": regions, "multiplier": body.demand_multiplier}}
            else:
                payload = {"type": "route_disruption", "start_tick": d["start_tick"], "duration_ticks": body.duration_ticks or 96, "parameters": {"route_ids": body.route_ids}}
            status, resp = await s.sim.post_json("/admin/events", payload)
            if status in (200, 201): d["forwarded"] = True; d["sim_response"] = resp; await s.refresh()
            else: forward_error = f"Simulator returned {status}: {resp}"
        except Exception as e: forward_error = str(e)
    elif forward: forward_error = f"{body.type} cannot be forwarded to the simulator (only DEMAND_SPIKE and ROUTE_DISRUPTION); applied in FuelSight only"
    row = s.ops.add_crisis(d)
    if body.severity in ("HIGH", "CRITICAL"): s.store.add_alert(f"crisis:{row['id']}", body.severity, f"Crisis: {body.title}", f"{body.type} - {body.note or 'no note'}", None, body.fuel_type)
    s.store.audit("crisis_create", "crisis", str(row["id"]), row); await s.broadcast({"type": "crisis", "id": row["id"], "action": "created"})
    return {**fx.with_state([row], s.tick())[0], "forward_error": forward_error}

@router.get("/{id}")
async def get_crisis(id: int, request: Request):
    s = request.app.state.fs; c = s.ops.crisis(id)
    if not c: raise HTTPException(404, "Crisis not found")
    return fx.with_state([c], s.tick())[0]

@router.post("/{id}/resolve")
async def resolve(id: int, request: Request):
    s = request.app.state.fs
    if not s.ops.crisis(id): raise HTTPException(404, "Crisis not found")
    c = s.ops.resolve_crisis(id); s.store.audit("crisis_resolve", "crisis", str(id), None); await s.broadcast({"type": "crisis", "id": id, "action": "resolved"})
    return fx.with_state([c], s.tick())[0]

@router.delete("/{id}")
async def delete(id: int, request: Request):
    if not request.app.state.fs.ops.delete_crisis(id): raise HTTPException(404, "Crisis not found")
    return {"status": "deleted", "id": id}
