from fastapi import APIRouter,Request,HTTPException
router=APIRouter(prefix="/api/sim",tags=["simulator"])
async def admin(request,path,payload):
    s=request.app.state.fs
    try:
        status,data=await s.sim.post_json("/admin/"+path,payload);await s.refresh();return {"status":status,"data":data}
    except Exception as e:raise HTTPException(503,{"code":"SIMULATOR_UNAVAILABLE","message":str(e)})
@router.post("/run")
async def run(request:Request):return await admin(request,"run",{})
@router.post("/pause")
async def pause(request:Request):return await admin(request,"pause",{})
@router.post("/toggle")
async def toggle(request:Request):return await admin(request,"toggle",{})
@router.post("/step")
async def step(request:Request):return await admin(request,"step",{})
@router.post("/reset")
async def reset(request:Request):return await admin(request,"reset",{})
@router.post("/events")
async def event(body:dict,request:Request):return await admin(request,"events",body)
@router.post("/faults")
async def fault(body:dict,request:Request):return await admin(request,"faults",body)
@router.post("/faults/clear")
async def clear(request:Request):return await admin(request,"faults/clear",{})
