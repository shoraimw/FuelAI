from typing import Literal, Optional
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from ..state import FUELS

router = APIRouter(prefix="/api", tags=["inventory & status"])

class StationStatus(BaseModel):
    status: Literal["OPEN", "CLOSED"]
    reason: Optional[str] = None

class DepotStatus(BaseModel):
    status: Literal["OPEN", "CONSTRAINED", "CLOSED"]
    reason: Optional[str] = None

def _fill(inv, cap):
    return round(100 * inv / cap, 1) if cap else 0.0

def _region_names(s):
    return {r["id"]: r.get("name", r["id"]) for r in s.snapshot("regions", [])}

@router.get("/inventory/stations")
async def inventory_stations(request: Request, region_id: Optional[str] = None, fuel: Optional[str] = None, status: Optional[str] = None):
    """Current fuel inventory + operating status of every station (simulator data + operator/crisis overrides)."""
    s = request.app.state.fs
    risks, _ = s.risk_table()
    by = {(r["station_id"], r["fuel_type"]): r for r in risks}
    names = _region_names(s)
    out = []
    for st in s.stations_eff():
        if region_id and st.get("region_id") != region_id: continue
        if status and st.get("status") != status: continue
        fuels = []
        for f in FUELS:
            if fuel and f != fuel.upper(): continue
            inv = float(st.get("inventory", {}).get(f, 0)); cap = float(st.get("capacity", {}).get(f, 0)); r = by.get((st["id"], f), {})
            fuels.append({"fuel_type": f, "inventory_liters": round(inv, 2), "capacity_liters": cap, "fill_percent": _fill(inv, cap),
                          "forecast_liters_per_hour": r.get("forecast_demand_per_hour"), "hours_to_stockout": r.get("hours_to_stockout"), "risk": r.get("risk", "LOW")})
        order = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
        out.append({"id": st["id"], "name": st.get("name"), "region_id": st.get("region_id"), "region_name": names.get(st.get("region_id")),
                    "status": st.get("status"), "status_source": st.get("status_source"), "sim_status": st.get("sim_status"),
                    "demand_profile": st.get("demand_profile"), "demand_multiplier": st.get("demand_multiplier"), "fuels": fuels,
                    "total_inventory_liters": round(sum(x["inventory_liters"] for x in fuels), 2), "total_capacity_liters": sum(x["capacity_liters"] for x in fuels),
                    "worst_risk": max((x["risk"] for x in fuels), key=order.index, default="LOW")})
    return out

@router.get("/inventory/depots")
async def inventory_depots(request: Request, region_id: Optional[str] = None):
    s = request.app.state.fs; names = _region_names(s); out = []
    for d in s.depots_eff():
        if region_id and d.get("region_id") != region_id: continue
        fuels = [{"fuel_type": f, "inventory_liters": round(float(d.get("inventory", {}).get(f, 0)), 2), "capacity_liters": float(d.get("capacity", {}).get(f, 0)),
                  "fill_percent": _fill(float(d.get("inventory", {}).get(f, 0)), float(d.get("capacity", {}).get(f, 0)))} for f in FUELS]
        vs = s.ops.vehicles(depot_id=d["id"])
        out.append({"id": d["id"], "name": d.get("name"), "region_id": d.get("region_id"), "region_name": names.get(d.get("region_id")), "status": d.get("status"),
                    "status_source": d.get("status_source"), "sim_status": d.get("sim_status"), "dispatch_capacity_per_tick": d.get("dispatch_capacity_per_tick"),
                    "fuels": fuels, "vehicles_total": len(vs), "vehicles_available": sum(1 for v in vs if v["status"] == "AVAILABLE")})
    return out

@router.get("/inventory/summary")
async def inventory_summary(request: Request):
    s = request.app.state.fs; stations = s.stations_eff(); depots = s.depots_eff(); risks, _ = s.risk_table(); per = {}
    for f in FUELS:
        si = sum(float(x.get("inventory", {}).get(f, 0)) for x in stations); sc = sum(float(x.get("capacity", {}).get(f, 0)) for x in stations)
        di = sum(float(x.get("inventory", {}).get(f, 0)) for x in depots); dc = sum(float(x.get("capacity", {}).get(f, 0)) for x in depots)
        per[f] = {"stations_inventory_liters": round(si, 2), "stations_capacity_liters": sc, "stations_fill_percent": _fill(si, sc),
                  "depots_inventory_liters": round(di, 2), "depots_capacity_liters": dc, "depots_fill_percent": _fill(di, dc)}
    def count(rows, key):
        c = {}
        for r in rows: c[r.get(key)] = c.get(r.get(key), 0) + 1
        return c
    return {"tick": s.tick(), "mode": s.mode, "stale": s.sim.stale, "fuels": per, "station_status": count(stations, "status"), "depot_status": count(depots, "status"),
            "risk_counts": count(risks, "risk"), "stations": len(stations), "depots": len(depots)}

@router.get("/stations")
async def list_stations(request: Request, region_id: Optional[str] = None, status: Optional[str] = None):
    return [x for x in request.app.state.fs.stations_eff() if (not region_id or x.get("region_id") == region_id) and (not status or x.get("status") == status)]

@router.get("/depots")
async def list_depots(request: Request, region_id: Optional[str] = None, status: Optional[str] = None):
    return [x for x in request.app.state.fs.depots_eff() if (not region_id or x.get("region_id") == region_id) and (not status or x.get("status") == status)]

def _exists(items, id, what):
    if not any(x["id"] == id for x in items): raise HTTPException(404, f"{what} not found")

@router.post("/stations/{id}/status")
async def set_station_status(id: str, body: StationStatus, request: Request):
    """Operator override (FuelSight side; the official simulator is untouched). Affects risk, recommendations and approval pre-checks."""
    s = request.app.state.fs; _exists(s.snapshot("stations", []), id, "Station")
    s.ops.set_status_override("station", id, body.status, body.reason); s.store.audit("station_status", "station", id, body.model_dump())
    await s.broadcast({"type": "status", "entity": "station", "id": id})
    return next(x for x in s.stations_eff() if x["id"] == id)

@router.delete("/stations/{id}/status")
async def clear_station_status(id: str, request: Request):
    s = request.app.state.fs; _exists(s.snapshot("stations", []), id, "Station"); s.ops.clear_status_override("station", id)
    return next(x for x in s.stations_eff() if x["id"] == id)

@router.post("/depots/{id}/status")
async def set_depot_status(id: str, body: DepotStatus, request: Request):
    s = request.app.state.fs; _exists(s.snapshot("depots", []), id, "Depot")
    s.ops.set_status_override("depot", id, body.status, body.reason); s.store.audit("depot_status", "depot", id, body.model_dump())
    await s.broadcast({"type": "status", "entity": "depot", "id": id})
    return next(x for x in s.depots_eff() if x["id"] == id)

@router.delete("/depots/{id}/status")
async def clear_depot_status(id: str, request: Request):
    s = request.app.state.fs; _exists(s.snapshot("depots", []), id, "Depot"); s.ops.clear_status_override("depot", id)
    return next(x for x in s.depots_eff() if x["id"] == id)
