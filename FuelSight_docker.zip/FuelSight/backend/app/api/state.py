from fastapi import APIRouter,Request,HTTPException
router=APIRouter(prefix="/api",tags=["state"])
@router.get("/state/overview")
async def overview(request:Request):
    s=request.app.state.fs
    return {"instance":s.snapshot("instance",{}),"regions":s.snapshot("regions",[]),"depots":s.snapshot("depots",[]),"stations":s.snapshot("stations",[]),
      "routes":s.snapshot("routes",[]),"supply_arrivals":s.snapshot("supply-arrivals",[]),"events":s.snapshot("events",[]),"allocations":s.snapshot("allocations",[]),
      "metrics":s.snapshot("metrics",{}),"mode":s.mode,"stale":s.sim.stale,"circuit_breaker":s.sim.cb.state,"last_simulator_ok":s.sim.last_ok}
@router.get("/stations/{id}")
async def station(id:str,request:Request):
    x=next((x for x in request.app.state.fs.snapshot("stations",[]) if x["id"]==id),None)
    if not x:raise HTTPException(404,"Not found")
    return x
@router.get("/depots/{id}")
async def depot(id:str,request:Request):
    x=next((x for x in request.app.state.fs.snapshot("depots",[]) if x["id"]==id),None)
    if not x:raise HTTPException(404,"Not found")
    return x
@router.get("/routes")
async def routes(request:Request):return request.app.state.fs.snapshot("routes",[])
@router.get("/supply-arrivals")
async def supply(request:Request):return request.app.state.fs.snapshot("supply-arrivals",[])
