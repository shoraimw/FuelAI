from statistics import mean
from typing import Optional
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel, Field
from ..state import FUELS

router = APIRouter(prefix="/api/regions", tags=["regional demand"])

class DemandOverride(BaseModel):
    multiplier: float = Field(gt=0.1, le=5.0, description="1.0 = normal, 1.5 = +50% demand")
    note: Optional[str] = None

def _observed_per_hour(s, station_id, fuel):
    rows = s.store.demand(station_id, fuel, 4)
    return mean(float(r["demand_liters"]) for r in rows) * 4 if rows else 0.0

def _build(s, region, with_hourly=False):
    risks, fcs = s.risk_table(); rk = {(r["station_id"], r["fuel_type"]): r for r in risks}
    ov = s.ops.region_overrides().get(region["id"]); e = s.effects()
    stations = [x for x in s.stations_eff() if x.get("region_id") == region["id"]]
    fuels = {f: {"forecast_liters_per_hour": 0.0, "forecast_24h_liters": 0.0, "observed_liters_per_hour": 0.0, "inventory_liters": 0.0, "capacity_liters": 0.0} for f in FUELS}
    rows = []; counts = {"LOW": 0, "MEDIUM": 0, "HIGH": 0, "CRITICAL": 0}; hourly = [{"hour": h + 1, **{f: 0.0 for f in FUELS}} for h in range(24)]
    for st in stations:
        row = {"station_id": st["id"], "station_name": st.get("name"), "status": st.get("status"), "demand_multiplier": st.get("demand_multiplier"), "fuels": {}}
        for f in FUELS:
            fc = fcs[(st["id"], f)]; r = rk[(st["id"], f)]; counts[r["risk"]] += 1; obs = _observed_per_hour(s, st["id"], f)
            inv = float(st.get("inventory", {}).get(f, 0)); cap = float(st.get("capacity", {}).get(f, 0))
            fuels[f]["forecast_liters_per_hour"] += r["forecast_demand_per_hour"]; fuels[f]["forecast_24h_liters"] += fc["daily_estimate_liters"]
            fuels[f]["observed_liters_per_hour"] += obs; fuels[f]["inventory_liters"] += inv; fuels[f]["capacity_liters"] += cap
            row["fuels"][f] = {"forecast_liters_per_hour": r["forecast_demand_per_hour"], "observed_liters_per_hour": round(obs, 2), "inventory_liters": round(inv, 2), "hours_to_stockout": r["hours_to_stockout"], "risk": r["risk"]}
            for h, v in enumerate(fc["hourly_liters"][:24]): hourly[h][f] += v
        rows.append(row)
    for f in FUELS:
        x = fuels[f]; x["cover_hours"] = round(x["inventory_liters"] / max(x["forecast_liters_per_hour"], .1), 1)
        for k in list(x): x[k] = round(x[k], 2)
    out = {"region_id": region["id"], "name": region.get("name"), "demand_factor": region.get("demand_factor", 1.0), "operator_override": ov,
           "crisis_multiplier": round(e["region_mult"].get(region["id"], 1.0), 3), "stations": len(stations), "risk_counts": counts, "fuels": fuels,
           "total_forecast_liters_per_hour": round(sum(fuels[f]["forecast_liters_per_hour"] for f in FUELS), 2),
           "total_forecast_24h_liters": round(sum(fuels[f]["forecast_24h_liters"] for f in FUELS), 2)}
    if with_hourly:
        out["station_rows"] = rows
        out["hourly_forecast"] = [{**{k: round(v, 2) for k, v in h.items()}, "total": round(sum(h[f] for f in FUELS), 2)} for h in hourly]
    return out

@router.get("/demand")
async def regional_demand(request: Request):
    s = request.app.state.fs
    return {"tick": s.tick(), "regions": [_build(s, r) for r in s.snapshot("regions", [])]}

@router.get("/{region_id}/demand")
async def region_demand(region_id: str, request: Request):
    s = request.app.state.fs; r = next((x for x in s.snapshot("regions", []) if x["id"] == region_id), None)
    if not r: raise HTTPException(404, "Region not found")
    return _build(s, r, with_hourly=True)

@router.post("/{region_id}/demand-override")
async def set_override(region_id: str, body: DemandOverride, request: Request):
    """Planning multiplier applied on top of the simulator demand for every station in the region (local only)."""
    s = request.app.state.fs
    if not any(x["id"] == region_id for x in s.snapshot("regions", [])): raise HTTPException(404, "Region not found")
    s.ops.set_region_override(region_id, body.multiplier, body.note); s.store.audit("region_demand_override", "region", region_id, body.model_dump())
    await s.broadcast({"type": "regional_demand", "region_id": region_id})
    return next(_build(s, r) for r in s.snapshot("regions", []) if r["id"] == region_id)

@router.delete("/{region_id}/demand-override")
async def clear_override(region_id: str, request: Request):
    s = request.app.state.fs
    if not any(x["id"] == region_id for x in s.snapshot("regions", [])): raise HTTPException(404, "Region not found")
    s.ops.clear_region_override(region_id)
    return next(_build(s, r) for r in s.snapshot("regions", []) if r["id"] == region_id)
