from prometheus_client import Counter,Histogram,Gauge
REQUESTS=Counter("fuelsight_requests_total","Total API requests",["method","path","status"])
LATENCY=Histogram("fuelsight_request_latency_seconds","API latency",["method","path"])
FALLBACKS=Counter("fuelsight_fallback_activations_total","Fallback activations")
PREDICTION_CONF=Gauge("fuelsight_prediction_confidence","Current prediction confidence")
SERVICE_LEVEL=Gauge("fuelsight_service_level","Simulator service level")
SIMULATOR_UP=Gauge("fuelsight_simulator_up","Simulator health")
STALE=Gauge("fuelsight_simulator_stale","Simulator stale-data signal")
