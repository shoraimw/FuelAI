import http from 'k6/http';
import {check,sleep} from 'k6';
export const options={vus:10,duration:'30s',thresholds:{http_req_failed:['rate<0.05'],http_req_duration:['p(95)<800','p(99)<1500']}};
export default function(){const r=http.get('http://127.0.0.1:8001/api/state/overview');check(r,{'overview 200':x=>x.status===200});sleep(.2);}
